//
//  HomeViewVM.swift
//  acls.ai
//
//  Created by Developer1 on 17/07/24.
//

import SwiftUI
//import PaywallKit
import StoreKit

struct ChecklistItem: Identifiable {
    let id = UUID()
    let description: String
}

struct PaymentView: View {
    @EnvironmentObject private var entitlementManager: EntitlementManager
    @EnvironmentObject private var subscriptionsManager: SubscriptionsManager
    @State private var selectedProduct: Product? = nil
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @StateObject var viewModel: PaymentViewVM = PaymentViewVM()

    let items: [ChecklistItem] = [
        ChecklistItem(description: "Intuitive design to rapidly access ACLS algorithms and content"),
        ChecklistItem(description: "Easy-to-read timers and logs for CPR, epinephrine, and defibrillations"),
        ChecklistItem(description: "Designed by Harvard-trained doctors for bedside care"),
        ChecklistItem(description: "Regularly updated with the most up-to-date content"),
        ChecklistItem(description: "Iterations based on clinician and nursing feedback")
    ]
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack{
                unlockAccessView
                    .onAppear {
                        Task {
                            await subscriptionsManager.loadProducts()
                        }
                    }
                    .navigationBarBackButtonHidden()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.appBlackLight)
            .cornerRadius(10)
            .padding(.horizontal,20.asDeviceWidth)
            .navigationDestination(isPresented: $viewModel.shouldShowHomeView) {
                HomeView()
            }
        }
    }
    
    private var closeButtonView: some View{
        HStack{
            Spacer()
            AppImages.systemClose
                .frame(width: 30.asDeviceWidth,height: 30.asDeviceWidth)
                .foregroundStyle(.appLime)
                .onTapGesture {
                    viewPresentMode.wrappedValue.dismiss()
                }
        }
        .padding(.horizontal, 20.asDeviceWidth)
    }
    
    private var unlockAccessView: some View{
        VStack(spacing: 30.asDeviceWidth){
            let freeTrialStartDate = Date(milliseconds: KeychainStorageManager.freeTrialStartDate)
            let isFreeTrialCompeled = freeTrialStartDate.IsDateAfter3Days()
            if isFreeTrialCompeled{
                closeButtonView
            }
            
            Text("Unlock Access")
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(30.asDeviceWidth, .bold))
            
            VStack(alignment: .leading, spacing: 15.asDeviceHeight){
                ForEach(0..<items.count, id: \.self){ index in
                    HStack(spacing: 20.asDeviceWidth) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.appLimeColor)
                        Text(items[index].description)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.leading)
                            .font(.inter(18.asDeviceWidth, .regular))
                    }
                    .padding(.horizontal, 10.asDeviceWidth)
                }
            }
            .padding(.horizontal, 15.asDeviceWidth)
            .background(Color.appBlackLightColor)
            
            startFreeTrialButtonView
//            Spacer()

            cancelFreeTrialView
            
            restorePurchaseView
                .padding(.bottom,20.asDeviceHeight)
        }
        .padding(.top, 20.asDeviceHeight)
    }
    
    private var startFreeTrialButtonView: some View{
        VStack(spacing: 25.asDeviceWidth){
            Text( !subscriptionsManager.products.isEmpty ? "Try 3 days free, then \(subscriptionsManager.products.first?.displayPrice ?? "0.0")/year" : "Try 3 days free, then $0/year")
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(18.asDeviceWidth, .regular))
            
            Button {
                if (!KeychainStorageManager.isUserSubscribed && !KeychainStorageManager.isUserInFreeTrial){
                    KeychainStorageManager.isUserInFreeTrial = true
                    KeychainStorageManager.freeTrialStartDate = Date().millisecondsSince1970
                    viewModel.shouldShowHomeView = true
                }else{
                    if let purchaseProduct = subscriptionsManager.products.first {
                        Task {
                            await subscriptionsManager.buyProduct(purchaseProduct)
                            if entitlementManager.hasPro {
                                KeychainStorageManager.isUserInFreeTrial = false
                                KeychainStorageManager.isUserSubscribed = true
                                viewModel.shouldShowHomeView = true
                                viewPresentMode.wrappedValue.dismiss()
                            }else{
                                if entitlementManager.hasErrorWhileSubscribe{
                                    print("ERORRRRRRRRR: - ")
                                }
                            }
                        }
                    } else {
                        print("Please select a product before purchasing.")
                    }
                }
            } label: {
                Text((!KeychainStorageManager.isUserSubscribed && !KeychainStorageManager.isUserInFreeTrial) ? "Start Free Trial" : "Purchase")
                    .textCase(.uppercase)
                    .foregroundColor(.appBlackLight)
                    .font(.inter(22.asDeviceWidth, .bold))
            }
            .padding(.horizontal)
            .frame(height: 55.asDeviceHeight)
            .frame(minWidth: 80)
            .background(Color.appSkyColor)
            .cornerRadius(8)
        }
    }
    
    private var cancelFreeTrialView: some View{
        VStack(alignment: .leading, spacing: 20.asDeviceWidth){
            Text("Cancel Anytime")
                .foregroundColor(.white)
                .frame(alignment: .leading)
                .font(.inter(18.asDeviceWidth, .bold))
            
            VStack(alignment:.leading){
                Text("If you cancel before the end of the free trial, you will not be charged after the free trial period, your account will be automatically charged. Subscriptions continue automatically until you cancel. To cancel, please turn off auto-renew at least 24-hours before the end of your current billing period. Auto renewal may be disabled at any time by going to your settings in the iTunes store after purchase. By tapping free trial, you agree to our ")
                    .foregroundColor(.white)
                    .font(.inter(16.asDeviceWidth, .regular))
                +
                Text("Terms of Use")
                    .foregroundColor(.white)
                    .font(.inter(16.asDeviceWidth, .bold))
                    .underline()
                +
                Text(" and acknowledge that you have read our ")
                    .foregroundColor(.white)
                    .font(.inter(16.asDeviceWidth, .regular))
                +
                Text("Privacy Policy.")
                    .foregroundColor(.white)
                    .font(.inter(16.asDeviceWidth, .bold))
                    .underline()
            }
        }
        .padding(.horizontal)
    }
    
    private var restorePurchaseView: some View{
        VStack {
            HStack(spacing: 0) {
                Text("Already purchased? ")
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                    .font(.inter(16.asDeviceWidth, .regular))
                
                Button(action: {
                    print("Restore tapped..")
                    Task {
                        await subscriptionsManager.restorePurchases()
                        KeychainStorageManager.isUserInFreeTrial = false
                        KeychainStorageManager.isUserSubscribed = true
                        viewModel.shouldShowHomeView = true
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }) {
                    Text("Restore")
                        .foregroundColor(.appLimeColor)
                        .font(.inter(16.asDeviceWidth, .bold))
                }
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: 20.asDeviceHeight)
    }
}

#Preview {
    PaymentView()
}
