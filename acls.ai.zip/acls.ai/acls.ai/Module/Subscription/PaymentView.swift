//
//  HomeViewVM.swift
//  acls.ai
//
//  Created by Developer1 on 17/07/24.
//

import SwiftUI
//import PaywallKit
import StoreKit

struct ChecklistItem: Identifiable {
    let id = UUID()
    let description: String
}

struct PaymentView: View {
    @EnvironmentObject private var entitlementManager: EntitlementManager
    @EnvironmentObject private var subscriptionsManager: SubscriptionsManager
    @State private var selectedProduct: Product? = nil
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @StateObject var viewModel: PaymentViewVM = PaymentViewVM()

    let items: [ChecklistItem] = [
        ChecklistItem(description: "Intuitive design to rapidly access ACLS algorithms and content"),
        ChecklistItem(description: "Easy-to-read timers and logs for CPR, epinephrine, and defibrillations"),
        ChecklistItem(description: "Designed by Harvard-trained doctors for bedside care"),
        ChecklistItem(description: "Regularly updated with the most up-to-date content"),
        ChecklistItem(description: "Iterations based on clinician and nursing feedback")
    ]
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack{
                unlockAccessView
                    .navigationBarBackButtonHidden()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .background(.appBlackLight)
            .cornerRadius(10)
            .padding(.horizontal,20.asDeviceWidth)
            .navigationDestination(isPresented: $viewModel.shouldShowHomeView) {
                HomeView()
            }
        }
    }
    
    private var closeButtonView: some View{
        HStack{
            Spacer()
            AppImages.systemClose
                .frame(width: 30.asDeviceWidth,height: 30.asDeviceWidth)
                .foregroundStyle(.appLime)
                .onTapGesture {
                    viewPresentMode.wrappedValue.dismiss()
                }
        }
        .padding(.horizontal, 20.asDeviceWidth)
    }
    
    private var unlockAccessView: some View{
        VStack(spacing: 30.asDeviceWidth){
            if (!KeychainStorageManager.isAgreeLegalDisclaimer && !KeychainStorageManager.isUserSubscribed) || (KeychainStorageManager.isUserInFreeTrial && !KeychainStorageManager.isUserSubscribed){
                closeButtonView
            }
            
            Text("Unlock Access")
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(24.asDeviceWidth, .bold))
            
            VStack(alignment: .leading, spacing: 20.asDeviceHeight){
                ForEach(0..<items.count, id: \.self){ index in
                    HStack(spacing: 20.asDeviceWidth) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.appLimeColor)
                        Text(items[index].description)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.leading)
                            .font(.inter(14.asDeviceWidth, .regular))
                    }
                    .padding(.horizontal, 20.asDeviceWidth)
                }
            }
            .padding(.horizontal, 20.asDeviceWidth)
            .background(Color.appBlackLightColor)
            
            startFreeTrialButtonView
            Spacer()

            cancelFreeTrialView
            
            restorePurchaseView
                .padding(.bottom,20.asDeviceHeight)
        }
        .padding(.top, 20.asDeviceHeight)
    }
    
    private var startFreeTrialButtonView: some View{
        VStack(spacing: 20.asDeviceWidth){
            Text("Try 3 days free, then $9.00/year")
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(14.asDeviceWidth, .regular))
            
            Button {
                KeychainStorageManager.isUserInFreeTrial = true
                KeychainStorageManager.freeTrialStartDate = Date().millisecondsSince1970
                viewModel.shouldShowHomeView = true
            } label: {
                Text((!KeychainStorageManager.isUserSubscribed && !KeychainStorageManager.isUserInFreeTrial) ? "Start Free Trial" : "Purchase")
                    .textCase(.uppercase)
                    .foregroundColor(.appBlackLight)
                    .font(.inter(19.asDeviceWidth, .bold))
            }
            .padding(.horizontal)
            .frame(height: 55.asDeviceHeight)
            .frame(minWidth: 80)
            .background(Color.appSkyColor)
            .cornerRadius(8)
        }
    }
    
    private var cancelFreeTrialView: some View{
        VStack(alignment: .leading, spacing: 20.asDeviceWidth){
            Text("Cancel Anytime")
                .foregroundColor(.white)
                .frame(alignment: .leading)
                .font(.inter(14.asDeviceWidth, .bold))
            
            VStack(alignment:.leading){
                Text("If you cancel before the end of the free trial, you will not be charged after the free trial period, your account will be automatically charged. Subscriptions continue automatically until you cancel. To cancel, please turn off auto-renew at least 24-hours before the end of your current billing period. Auto renewal may be disabled at any time by going to your settings in the iTunes store after purchase. By tapping free trial, you agree to our ")
                    .foregroundColor(.white)
                    .font(.inter(12.asDeviceWidth, .regular))
                +
                Text("Terms of Use")
                    .foregroundColor(.white)
                    .font(.inter(12.asDeviceWidth, .bold))
                    .underline()
                +
                Text(" and acknowledge that you have read our ")
                    .foregroundColor(.white)
                    .font(.inter(12.asDeviceWidth, .regular))
                +
                Text("Privacy Policy.")
                    .foregroundColor(.white)
                    .font(.inter(12.asDeviceWidth, .bold))
                    .underline()
            }
        }
        .padding(.horizontal)
    }
    
    private var restorePurchaseView: some View{
        VStack {
            HStack(spacing: 0) {
                Text("Already purchased? ")
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                    .font(.inter(12.asDeviceWidth, .regular))
                
                Button(action: {
                    print("Restore tapped..")
                }) {
                    Text("Restore")
                        .foregroundColor(.appLimeColor)
                        .font(.inter(12.asDeviceWidth, .bold))
                }
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: 20.asDeviceHeight)
    }
    
    
    // MARK: - Views
//    private var hasSubscriptionView: some View {
//        VStack(spacing: 20) {
//            Image(systemName: "crown.fill")
//                .foregroundStyle(Color.appLimeColor)
//                .font(Font.system(size: 100))
//            
//            Text("You've Unlocked Pro Access")
//                .font(.system(size: 30.0, weight: .bold))
//                .multilineTextAlignment(.center)
//                .padding(.horizontal, 30)
//                .foregroundStyle(.white)
//        }
//    }
    
    // MARK: - Views
    private var hasSubscriptionView: some View {
        VStack(spacing: 20) {
            Image(systemName: "crown.fill")
                .foregroundStyle(Color.appLimeColor)
                .font(Font.system(size: 100))
            
            Text("You've Unlocked Pro Access")
                .font(.system(size: 30.0, weight: .bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .foregroundStyle(.white)
        }
    }
    
    private var subscriptionOptionsView: some View {
        VStack(alignment: .center, spacing: 12.5) {
            if !subscriptionsManager.products.isEmpty {
                Spacer()
                proAccessView
                VStack(spacing: 2.5) {
                    productsListView
                    Spacer()
                    purchaseSection
                }
            } else {
                ProgressView()
                    .progressViewStyle(.circular)
                    .scaleEffect(1.5)
                    .ignoresSafeArea(.all)
            }
        }
    }
    
    private var proAccessView: some View {
        VStack(alignment: .center, spacing: 10) {
            Image(systemName: "dollarsign.circle.fill")
                .foregroundStyle(.appLime)
                .font(Font.system(size: 80))
            
            Text("Unlock Pro Access")
                .font(.system(size: 33.0, weight: .bold))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white)
            
            Text("Get access to all of our features")
                .font(.system(size: 17.0, weight: .semibold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .foregroundStyle(.white)
        }
    }
    
    private var productsListView: some View {
        List(subscriptionsManager.products, id: \.self) { product in
            SubscriptionItemView(product: product, selectedProduct: $selectedProduct)
                .listRowBackground(Color.appThemeColor)
        }
        .scrollDisabled(true)
        .listStyle(.plain)
        .listRowSpacing(2.5)
    }
    
    private var purchaseSection: some View {
        VStack(alignment: .center, spacing: 15) {
            purchaseButtonView
            
            Button("Restore Purchases") {
                Task {
                    await subscriptionsManager.restorePurchases()
                }
            }
            .font(.system(size: 14.0, weight: .regular, design: .rounded))
            .foregroundStyle(.white)
            .frame(height: 15, alignment: .center)
        }
    }
    
    private var purchaseButtonView: some View {
        Button(action: {
            if let selectedProduct = selectedProduct {
                Task {
                    await subscriptionsManager.buyProduct(selectedProduct)
                }
            } else {
                print("Please select a product before purchasing.")
            }
        }) {
            Text("Purchase")
                .foregroundStyle(.black)
                .font(.system(size: 16.5, weight: .semibold, design: .rounded))
        }
        .padding(.horizontal, 20)
        .frame(height: 46)
        .background(Color.appLime)
        .disabled(selectedProduct == nil)
        .cornerRadius(8)
    }
}

#Preview {
    PaymentView()
}

// MARK: Subscription Item
struct SubscriptionItemView: View {
    var product: Product
    @Binding var selectedProduct: Product?
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12.5)
                .stroke(selectedProduct == product ? Color.appLimeColor : .gray, lineWidth: 1.0)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.appThemeColor))
            
            HStack {
                VStack(alignment: .leading, spacing: 8.5) {
                    Text(product.displayName)
                        .font(.system(size: 16.0, weight: .semibold, design: .rounded))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                    
                    Text("Get full access for just \(product.displayPrice)")
                        .font(.system(size: 14.0, weight: .regular, design: .rounded))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                }
                Spacer()
                Image(systemName: selectedProduct == product ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(selectedProduct == product ? .appLimeColor : .gray)
            }
            .padding(.horizontal, 20)
            .frame(height: 65, alignment: .center)
        }
        .background(Color.appThemeColor)
        .onTapGesture {
            selectedProduct = product
        }
        .listRowSeparator(.hidden)
    }
}
