//
//  PaymentViewVM.swift
//  acls.ai
//
//  Created by Developer on 19/07/24.
//

import Foundation

@MainActor
final class PaymentViewVM: ObservableObject {
    @Published var shouldShowHomeView: Bool = false
}
