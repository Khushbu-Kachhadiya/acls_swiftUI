//
//  PostCardiaArrestCareInfoView.swift
//  acls.ai
//
//  Created by Developer on 27/05/24.
//

import SwiftUI

struct CardiacInfo: Identifiable, Hashable {
    let id = UUID()
    let title: String
    var isOn: Bool = false
    var description: String = ""
    var isSetcustomHStack:Bool = false
    var customViewDesc:[String] = []
}

struct PostCardiaArrestCareInfoView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @State var navigateToView: Bool = false
    
    static let item1 = CardiacInfo(title: K.header1, description: K.descp1)
    static let item2 = CardiacInfo(title: K.header2, description: K.descp2)
    static let item3 = CardiacInfo(title: K.header3, isSetcustomHStack: true, customViewDesc: ["\u{2022} Hypovolemia", "\u{2022} Hypoxia", "\u{2022} Hydrogen ion\n   (acidosis)", "\u{2022} Hypo-/\n   hyperkalemia", "\u{2022} Hypothermia", "\u{2022} Tension\n   Pneumothorax", "\u{2022} Tamponade, cardiac", "\u{2022} Toxins", "\u{2022} Thrombosis,\n   pulmanory","\u{2022} Thrombosis, coronary"])
    @State var items: [CardiacInfo] = [item1, item2, item3]
    
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal, 20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title: "Post Cardiac Arrest Care") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                VStack{
                    List {
                        ForEach(0..<items.count, id: \.self) { index in
                            Section(header: SectionHeaderView(data: items[index])
                                .background(Color.appBlackLightColor)
                                .onTapGesture {
                                    withAnimation {
                                        items[index].isOn.toggle()
                                    }
                                }) {
                                    if self.items[index].isOn {
                                        if self.items[index].isSetcustomHStack{
                                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                                                ForEach(self.items[index].customViewDesc, id: \.self) { type in
                                                    Text(type)
                                                        .foregroundColor(.white)
                                                        .font(.inter(16.asDeviceWidth, .regular))
                                                        .textCase(.none)
                                                        .frame(maxWidth: .infinity, alignment: .leading)
                                                        .padding(.top,10)
                                                }
                                            }
                                            .listRowBackground(Color.clear)
                                            .listRowSeparator(.hidden)
                                        }else{
                                            Text(self.items[index].description)
                                                .foregroundColor(.white)
                                                .font(.inter(16.asDeviceWidth, .regular))
                                                .textCase(.none)
                                                .padding(.top,10)
                                                .listRowBackground(Color.clear)
                                                .listRowSeparator(.hidden)
                                        }
                                    }
                                }
                                .listRowInsets(EdgeInsets())
                                .padding(.horizontal, 20)
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(GroupedListStyle())
                    .padding(.top)
                }
                .background(Color.appBlackLight)
                .frame(maxWidth: .infinity, alignment: .center)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationBarBackButtonHidden()
    }
    
    @ViewBuilder
    private func SectionHeaderView(data: CardiacInfo) -> some View {
        VStack(spacing: 0){
            SeperatorLineView(padHorizontal: false).padding(.bottom)
            HStack{
                Text(data.title).foregroundColor(.white)
                    .frame(alignment: .leading)
                    .font(.inter(16.asDeviceWidth, .regular))
                    .textCase(.none)
                Spacer()
                Button(action: {
                    
                }, label: {
                    if data.isOn {
                        Image.appIcn_minus
                    } else {
                        Image.appIcn_plus
                    }
                })
                .font(Font.caption)
                .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    PostCardiaArrestCareInfoView()
}

private extension PostCardiaArrestCareInfoView {
    enum K {
        static var header1 = "Initial Stabilization Phase"
        static var descp1 = """
        Resuscitation is ongoing during the post-ROSC phase, and many of these activities can occur
        concurrently. However, if prioritization is necessary, follow these steps: \n
        \u{2022} Airway management: Waveform capnography or capnometry to confirm and monitor endotracheal
        tube placement\n
        \u{2022} Manage respiratory parameters: Administer crystalloid and/or vasopressor or inotrope for goal systolic blood pressure >90 mm Hg or mean arterial pressure >65 mm HG
        """
        
        static var header2 = "Continued Management and Additional Emmergent Activities"
        static var descp2 = """
        These evaluations should be done concurrently so that decisions on targeted temperature management (TTM) receive high priority as cardiac interventions. \n
        \u{2022} Emergent cardiac intervention: Early evaluation of 12-lead electrocardiogram (ECG); consider hemodynamics for decision on cardiac intervention \n
        \u{2022} TTM: if patient is not following commands, start TTM as soon as possible; begin at 32-36 °C for 24 hours by using a cooling device with feedback loop \n
        \u{2022} Other critical care management
            \u{2022} Continuously monitor core temperature (esophageal, rectal, bladder)
            \u{2022} Maintain normoxia, normocapnia, euglycemia
            \u{2022} Provide continuous or intermittent electroencephalogram (EEG) monitoring
            \u{2022} Provide lung-protective ventilation
        """
        
        static var header3 = "H’s and T’s"
    }
}
