//
//  PostCardiaArrestCareStates.swift
//  acls.ai
//
//  Created by Developer on 27/05/24.
//

import Foundation

enum PostCardiaArrestCareStates {
    static var start = StepModel(
        title: "ROSC obtained",
        subTitle: """
        ROSC
        """,
        isPreviousStepCompleted: true
    )
    
    static var manageairway = StepModel(
        title: "Manage airway",
        subTitle: """
        Early placement of endotracheal tube \n
        Manage respiratory parameters \n
        \u{2022} Start 10 breaths/min
        \u{2022} SpO2 92%-98%
        \u{2022} PaC02 35-45 mm Hg \n
        Manage hemodynamic parameters \n
        \u{2022} Systolic blood pressure >90 mm Hg
        \u{2022} Mean arterial pressure >65 mm Hg
        """
    )
    
    static var obtainECG = StepModel(
        title: "Obtain 12-lead ECG",
        subTitle: """
        """
    )
    
    static var emergentcardiac = StepModel(
        title: "Consider for emergent cardiac inventory if:",
        subTitle: """
        \u{2022} STEMI present
        \u{2022} Unstable cardiogenic shock
        \u{2022} Mechanical circulatory support required
        """
    )
       
    static var followsCommands = StepModel(
        title: "Follows Commands? ",
        buttonTypes: [.no, .yes],
        yesStage: ButtonModal(Nextstage: followsCommandsYesSteps, isSelected: false),
        noStage:  ButtonModal(Nextstage: followsCommandsNoSteps, isSelected: false)
    )
    
    static var Awake = StepModel(
        title: "Awake",
        subTitle: """
        Other critical care management
        """,
        isLastStep: true
    )
    
    static var followsCommandsYesSteps = [Awake]
    
    static var comatose = StepModel(
        title: "Monitor and observe",
        subTitle: """
        \u{2022} TTM
        \u{2022} Obtain brain CT
        \u{2022} EEG monitoring
        \u{2022} Other critical care management
        """,
        isLastStep: true
    )
    
    static var followsCommandsNoSteps = [comatose]
    
    static var stage0 = [
        start,
        manageairway,
        obtainECG,
        emergentcardiac,
        followsCommands,
        Globals.unknownStep
    ]
}
