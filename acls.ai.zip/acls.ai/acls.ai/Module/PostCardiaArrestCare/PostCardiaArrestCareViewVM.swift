//
//  CardiacArrestViewVM.swift
//  acls.ai
//
//  Created by Developer1 on 05/04/24.
//

import Foundation
import SwiftUI

enum PostCardiaArrestCareOptions{
    case CPR_Quality
    case Medication
    
    var description: String {
        switch self {
        case .CPR_Quality:
            return "CPR_Quality"
        case .Medication:
            return "Medication"
        }
    }
}

@MainActor
final class PostCardiaArrestCareViewVM: ObservableObject {
    @Published var navigateToView: Bool = false
    @Published var postCardiacArray: [StepModel] = PostCardiaArrestCareStates.stage0
    @Published var progress: Double = 0
    @Published var timerIsRunning = false
    @Published private var elapsedTime = 0.0
    @Published var shouldShowInfo = false
    var stepTimer: Timer?
    
    func updateProgressAsPerStepsCompleted(){
        let stepsCompleted = postCardiacArray.filter({$0.isCurrentStepCompleted ?? false}).count
        let x = Double(stepsCompleted) / Double(postCardiacArray.count)
        let y = Double(round(100 * x) / 100)
        self.progress = y
    }
    
    func startTimer() {
        stepTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.elapsedTime += 1
        }
    }
    
    func stopTimer() {
        stepTimer?.invalidate()
        stepTimer = nil
    }
    
    func timeString() -> String {
//        let hours = Int(time) / 3600
        let minutes = Int(elapsedTime) / 60 % 60
        let seconds = Int(elapsedTime) % 60
//        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    func referesh(){
        progress = 0
        elapsedTime = 0
        postCardiacArray = PostCardiaArrestCareStates.stage0
        stopTimer()
    }
}
