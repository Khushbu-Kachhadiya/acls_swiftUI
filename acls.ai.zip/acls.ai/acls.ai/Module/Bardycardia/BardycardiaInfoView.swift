//
//  BardycardiaInfoView.swift
//  acls.ai
//
//  Created by Developer on 27/05/24.
//

import SwiftUI

struct BardycardiaInfoView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    
    struct Title: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(16, .bold))
                .padding(.horizontal, 8)
                .padding(.top, 16)
        }
    }
    
    struct Description: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(14, .regular))
                .multilineTextAlignment(.leading)
                .padding(.top,1)
                .padding(.horizontal, 8)
        }
    }

    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal, 20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title: "Bradycardia ") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                    
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading) {
                        Title(string: K.title)
                        SeperatorLineView(padHorizontal: false)
                        
                        Title(string: K.header1)
                        Description(string: K.descp1)
                        
                        Title(string: K.header2)
                        Description(string: K.descp2)
                        
                        Title(string: K.header3)
                        Description(string: K.descp3)
                        
                        Title(string: K.header4)
                        Description(string: K.descp4)
                        
                        Spacer()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .background(.appBlackLight)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview {
    BardycardiaInfoView()
}

private extension BardycardiaInfoView {
    enum K {
        static var title = "Doses/Details"
        
        static var header1 = "Atropine IV dose:"
        static var descp1 = """
        First dose: 1 mg bolus.
        Repeat every 3-5 minutes.
        Maximum: 3mg.
        """
        
        static var header2 = "Dopamine IV infusion:"
        static var descp2 = """
        Usual infusion rate is 5-20 mcg/kg per minute.
        Titrate to patient response; taper slowly.
        """
        
        static var header3 = "Epinephrine IV infusion:"
        static var descp3 = """
        20-50 mg/min until arrhythmia suppressed,
        Titrate to patient response.
        """
        
        static var header4 = "Causes"
        static var descp4 = """
        \u{2022} Myocardial ischemia/infraction
        \u{2022} Drugs/toxicologic (eg, calcium-channel blockers, beta blockers, digoxin)
        \u{2022} Hypoxia
        \u{2022} Electrolyte abnormality (eg, hyperkalemia)
        """
    }
}
