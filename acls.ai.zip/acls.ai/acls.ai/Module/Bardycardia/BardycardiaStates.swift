import Foundation

enum BardycardiaStates {
    static var start = StepModel(
        title: "Assess Appropriateness for clinical condition.",
        subTitle: "Heart rate Typical < 50/min if bradyarrhythmia.",
        isPreviousStepCompleted: true
    )
    
    static var identification = StepModel(
        title: "Identify and treat underlying cause",
        subTitle: """
        Maintain patient airway; assist breathing as necessary \n
        Oxygen (if hypoxemic) \n
        Cardiac Monitor to identify rhythm; monitor blood pressure and oximetry \n
        IV access \n
        12-lead ECG, if available; don’t delay therapy \n
        Consider possible hypoxic and toxicologic causes
        """
    )
       
    static var persistentTachya = StepModel(
        title: "Persistent bradyarrhythmia causing:",
        subTitle: """
        Hypertension? \n
        Acutely altered mental status? \n
        Signs of shock? \n
        Ischemic chest discomfort? \n
        Acute heart failure?
        """,
        buttonTypes: [.no, .yes],
        yesStage: ButtonModal(Nextstage: persistentTachyaYesSteps, isSelected: false),
        noStage:  ButtonModal(Nextstage: persistentTachyaNoSteps, isSelected: false)
    )
    
    static var atrophine = StepModel(
        title: "Atrophine",
        subTitle: """
        If atropine is ineffective: \n
        Transcutaneous pacing \n
        and/or \n
        Dopamine infusion \n
        or \n
        Epinephrine infusion
        """
    )
    
    static var consider = StepModel(
        title: "Consider:",
        subTitle: """
        Expert consultation \n
        Tranvenous pacing
        """,
        isLastStep: true
    )
    
    static var persistentTachyaYesSteps = [atrophine, consider]
    
    static var monitor = StepModel(
        title: "Monitor and observe",
        subTitle: """
        \n
        """,
        isLastStep: true
    )
    
    static var persistentTachyaNoSteps = [monitor]
    
    static var stage0 = [
        start,
        identification,
        persistentTachya,
        Globals.unknownStep
    ]
}
