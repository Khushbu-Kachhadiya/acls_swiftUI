//
//  CardiacArrestView.swift
//  acls.ai
//
//  Created by Developer1 on 05/04/24.
//

import SwiftUI

struct BardycardiaView: View{
    @State var title:String = ""
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @StateObject var viewModel: BardycardiaViewVM = BardycardiaViewVM()
    @State var currentIndex = 0
    @State var hideControlPanelTask: DispatchWorkItem?
    @State var reader: ScrollViewProxy?
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack{
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal,20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title:title) {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                VStack{
                    HStack {
                        Button {
                            viewModel.referesh()
                            withAnimation {
                                reader?.scrollTo(0, anchor: .top)
                            }
                        } label: {
                            AppImages.appIcn_refresh
                        }
                        .padding([.top, .leading], 22.asDeviceHeight)
                        Spacer()
                        Button {
                            viewModel.shouldShowInfo = true
                        } label: {
                            AppImages.infoGreen
                        }
                        .padding([.top, .trailing], 22.asDeviceHeight)
                    }
                    Spacer()
                    progressLoaderView
                        .padding(.bottom, 30)
                    stpesScrollView
//                    SeperatorLineView()
//                    AddOptionsView(title: CardiacArrestOptions.CPR_Quality.description)
//                    SeperatorLineView()
//                    AddOptionsView(title: CardiacArrestOptions.Medication.description)
//                    SeperatorLineView().padding(.bottom,20)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .background(.appBlackLight)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationDestination(isPresented: $viewModel.shouldShowInfo) {
            BardycardiaInfoView()
        }
        .navigationBarBackButtonHidden()
    }
    
    private var progressLoaderView: some View{
        CircularProgressView(progress: viewModel.progress)
            .frame(width: 200.asDeviceWidth,height: 200.asDeviceWidth)
    }
    
    private var stpesScrollView: some View{
        ZStack{
            ScrollView{
                ScrollViewReader { reader in
                    VStack(spacing: 0){
                        //1st step
                        Text("").frame(height: 30.asDeviceHeight)
                        ForEach(0..<viewModel.cardiacArray.count, id: \.self){ index in
                            TitleWithRoundStepper(steps: $viewModel.cardiacArray, index: index) {
                                updateProgress(index: index, reader: reader)
                                
                            }
                            .id(index)
                            .onAppear {
                                self.reader = reader
                            }
                        }
                        GeometryReader{ proxy in
                            Color.clear
                                .onChange(of: proxy.frame(in: .global).minY) { offsetY in
                                    hideControlPanelTask?.cancel()
                                    self.hideControlPanelTask = DispatchWorkItem {
                                        withAnimation {
                                        }
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.02, execute: hideControlPanelTask!)
                                }
                        }
                    }
                }
                
            }
        }
        .innerShadow(color: .appBlackLightColor,radius: 0.11)
    }
}

#Preview {
    BardycardiaView(title: "Bradycardia")
}

//MARK: - User Function
extension BardycardiaView {
    func updateProgress(index: Int, reader: ScrollViewProxy){
        if viewModel.cardiacArray[index].isPreviousStepCompleted == true,viewModel.cardiacArray[index].isCurrentStepCompleted == false{
            viewModel.cardiacArray[index].isCurrentStepCompleted = true
            if index < viewModel.cardiacArray.count - 1{
                viewModel.cardiacArray[index + 1].isPreviousStepCompleted = true
            }
            withAnimation {
                viewModel.updateProgressAsPerStepsCompleted()
                if index <  viewModel.cardiacArray.count - 1{
                    reader.scrollTo(index + 1, anchor: .center)
                    currentIndex = index + 1
                }
            }
        }
    }
}
