//
//  CardiacArrestModel.swift
//  acls.ai
//
//  Created by Developer on 26/04/24.
//

import Foundation
import SwiftUI

struct StepModel: Hashable {
    let title: String?
    let subTitle: String?
    let stepLogTitle: String?
    var buttonTypes: [ButtonType]?
    let titleImage: String?
    let description: String?
    var isCurrentStepCompleted: Bool?
    var isPreviousStepCompleted: Bool?
    var timer: String?
    var isStartButtonHidden: Bool?
    var yesStage: ButtonModal?
    var noStage: ButtonModal?
    var isLastStep : Bool
    
    init(
        title:String? = nil,
        subTitle:String? = nil,
        stepLogTitle: String? = nil,
        buttonTypes:[ButtonType]? = nil,
        titleImage:String? = nil,
        description:String? = nil,
        isCurrentStepCompleted:Bool? = false,
        isPreviousStepCompleted:Bool? = false,
        timer:String? = nil,
        isStartButtonHidden:Bool? = false,
        yesStage: ButtonModal? = nil,
        noStage: ButtonModal? = nil,
        isLastStep: Bool = false
    ) {
        self.title = title
        self.subTitle = subTitle
        self.stepLogTitle = stepLogTitle
        self.buttonTypes = buttonTypes
        self.description = description
        self.titleImage = titleImage
        self.isCurrentStepCompleted = isCurrentStepCompleted
        self.isPreviousStepCompleted = isPreviousStepCompleted
        self.timer = timer
        self.isStartButtonHidden = isStartButtonHidden
        self.yesStage = yesStage
        self.noStage = noStage
        self.isLastStep = isLastStep
    }
}

struct ButtonModal : Hashable {
    var Nextstage : [StepModel]
    var isSelected : Bool
    init(Nextstage: [StepModel], isSelected: Bool = false) {
        self.Nextstage = Nextstage
        self.isSelected = isSelected
    }
}

