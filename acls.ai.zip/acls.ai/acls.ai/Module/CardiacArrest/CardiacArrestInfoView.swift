//
//  CardiacArrestInfoView.swift
//  acls.ai
//
//  Created by Developer on 28/05/24.
//

import SwiftUI

struct CardiacArrestInfoView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    
    static let item1 = CardiacInfo(title: K.header1, description: K.descp1)
    static let item2 = CardiacInfo(title: K.header2, description: K.descp2)
    static let item3 = CardiacInfo(title: K.header3, description: K.descp3)
    static let item4 = CardiacInfo(title: K.header4, description: K.descp4)
    static let item5 = CardiacInfo(title: K.header5, description: K.descp5)
    static let item6 = CardiacInfo(title: K.header6, isSetcustomHStack: true, customViewDesc: ["\u{2022} Hypovolemia", "\u{2022} Hypoxia", "\u{2022} Hydrogen ion\n   (acidosis)", "\u{2022} Hypo-/\n   hyperkalemia", "\u{2022} Hypothermia", "\u{2022} Tension\n   Pneumothorax", "\u{2022} Tamponade, cardiac", "\u{2022} Toxins", "\u{2022} Thrombosis,\n   pulmanory","\u{2022} Thrombosis, coronary"])
    @State var items: [CardiacInfo] = [item1, item2, item3, item4, item5, item6]
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal, 20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title: "Cardiac Arrest") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                VStack{
                    List {
                        ForEach(0..<items.count, id: \.self) { index in
                            Section(header: SectionHeaderView(data: items[index])
                                .background(Color.appBlackLightColor)
                                .onTapGesture {
                                withAnimation {
                                    items[index].isOn.toggle()
                                }
                            }) {
                                if self.items[index].isOn {
                                    if self.items[index].isSetcustomHStack{
                                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                                            ForEach(self.items[index].customViewDesc, id: \.self) { type in
                                                Text(type)
                                                    .foregroundColor(.white)
                                                    .font(.inter(16.asDeviceWidth, .regular))
                                                    .textCase(.none)
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(.top,10)
                                            }
                                        }
                                        .listRowBackground(Color.clear)
                                        .listRowSeparator(.hidden)
                                    }else{
                                        Text(self.items[index].description)
                                            .foregroundColor(.white)
                                            .font(.inter(16.asDeviceWidth, .regular))
                                            .textCase(.none)
                                            .padding(.top,10)
                                            .listRowBackground(Color.clear)
                                            .listRowSeparator(.hidden)
                                    }
                                }
                            }
                            .listRowInsets(EdgeInsets())
                            .padding(.horizontal, 20)
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(GroupedListStyle())
                    .padding(.top)
                }
                .background(Color.appBlackLight)
                .frame(maxWidth: .infinity, alignment: .center)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationBarBackButtonHidden()
    }
    
    @ViewBuilder
    private func SectionHeaderView(data: CardiacInfo) -> some View {
        VStack(spacing: 0){
            SeperatorLineView(padHorizontal: false).padding(.bottom)
            HStack{
                Text(data.title).foregroundColor(.white)
                    .frame(alignment: .leading)
                    .font(.inter(16.asDeviceWidth, .regular))
                    .textCase(.none)
                Spacer()
                Button(action: {
                    
                }, label: {
                    if data.isOn {
                        Image.appIcn_minus
                    } else {
                        Image.appIcn_plus
                    }
                })
                .font(Font.caption)
                .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    CardiacArrestInfoView()
}

private extension CardiacArrestInfoView {
    enum K {
        static var header1 = "CPR Quality"
        static var descp1 = """
        \u{2022} Push hard (at least 2 inches [5cm]) and fast (100-120/min) and allow complete cest recoil. \n
        \u{2022} Minimize interruptions in compressions. \n
        \u{2022} Avoid excessive ventilation. \n
        \u{2022} Change compressor every 2 minutes, or sooner if fatigued.\n
        \u{2022} Quantitively waveform capnography
            \u{2022} Quantitively waveform capnography If PETCO2 is low or decreasing, reassess CPR quality.
        """
        
        static var header2 = "Shock Energy for Defibrillation"
        static var descp2 = """
        Biphasic: Manufacturer recommendation (eg, initial dose of 120-200 J); if unknown, use maximum available. Second and subsequent doses should be equivalent, and higher doses may be considered. \n
        Monophasic: 360 J
        """
        
        static var header3 = "Drug Therapy"
        static var descp3 = """
        Epinephrine IV/IO dose:
        1mg every 3-5 minutes \n
        Amiodarone IV/IO dose:
        First dose: 300mg bolus.
        Second dose: 150 mg. \n
        or \n
        Lidocaine IV/IO dose:
        First dose: 1-1.5 mg/kg.
        Second dose: 0.5 - 0.75 mg/kg
        """
        
        static var header4 = "Advance Airway"
        static var descp4 = """
        \u{2022} Endotracheal intubation or supraglottic advanced airway \n
        \u{2022} Waveform capnography or capnometry to confirm and monitor ET tube placement \n
        \u{2022} Once advanced airway in place, give 1 breath every 6 seconds (10 breaths/min) with
        continuous chest compressions \n
        """
        
        static var header5 = "Return of Spontaneous Circulation (ROSC)"
        static var descp5 = """
        \u{2022} Pulse and blood pressure \n
        \u{2022} Abrupt sustained increase in PETCO2 (typically 40 mm Hg) \n
        \u{2022} Spontaneous arterial pressure waves with intra-arterial monitoring \n
        """
        
        static var header6 = "Reversible Causes"
        static var descp6 = """
        \u{2022} Hypovolemia
        \u{2022} Hypoxia
        \u{2022} Hydrogen ion
                 (acidosis)
        \u{2022} Hypo-/
                 hyperkalemia
        \u{2022} Hypothermia
        \u{2022} Tension Pneumothorax
        \u{2022} Tamponade, cardiac
        \u{2022} Toxins
        \u{2022} Thrombosis, pulmanory
        \u{2022} Thrombosis, coronary
        """
    }
}
