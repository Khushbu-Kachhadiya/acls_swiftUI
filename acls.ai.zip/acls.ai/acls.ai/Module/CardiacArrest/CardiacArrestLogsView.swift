//
//  CardiacArrestLogsView.swift
//  acls.ai
//
//  Created by Developer on 05/06/24.
//

import SwiftUI

struct CardiacArrestLogsView: View {
    @StateObject var viewModel: CardiacArrestLogsViewVM = CardiacArrestLogsViewVM()
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @State var codeLogsArray: [CodeLogsModel]
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack{
//                VStack(alignment: .leading){
//                    HeaderTitleAndProfileNavigationView(navigateToView: viewModel.navigateToView)
//                        .padding(.horizontal,20.asDeviceWidth)
//                    
//                    HeaderNavigationTitleWithBackButton(title:"Cardiac Arrest") {
////                        viewPresentMode.wrappedValue.dismiss()
//                    }
//                }
                
                VStack{
                    HStack{
                        Button {
                            self.codeLogsArray.removeAll()
                            NotificationCenter.default.post(name: NSNotification.ResetCodeLogs, object: nil)
                        } label: {
                            Text("Reset")
                                .textCase(.uppercase)
                                .foregroundColor(.appBlackLight)
                                .font(.inter(19.asDeviceWidth, .bold))
                        }
                        .padding(.horizontal)
                        .frame(height: 55.asDeviceHeight)
                        .frame(minWidth: 80)
                        .background(Color.appRedColor)
                        .cornerRadius(8)
                        .padding([.top, .leading], 22.asDeviceHeight)
                        
                        Spacer()
                        Image.systemClose
                            .foregroundColor(.black)
                            .padding([.top, .trailing], 22.asDeviceHeight)
                            .onTapGesture {
                                viewPresentMode.wrappedValue.dismiss()
                            }
                    }
                    
                    Text("Code Logs")
                        .foregroundColor(.white)
                        .font(.inter(18.asDeviceWidth, .bold))
                        .textCase(.none)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top,10)
                    
                    if codeLogsArray.count > 0{
                        codeLogsView(data: codeLogsArray)
                            .padding(20)
                    }else{
                        SeperatorLineView(padHorizontal: false)
                        Text("Not logs added yet.")
                            .foregroundColor(.white)
                            .font(.inter(18.asDeviceWidth, .semibold))
                            .textCase(.none)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top,10)
                    }
                    
                    Spacer()
                }
                .background(Color.appBlackLight)
                .frame(maxWidth: .infinity, alignment: .center)
                .cornerRadius(10)
                .padding(20)
            }
        }
        .navigationBarBackButtonHidden()
    }
    
    @ViewBuilder
    private func codeLogsView(data: [CodeLogsModel]) -> some View {
        VStack(spacing: 10){
            ForEach(0..<data.count, id: \.self){ index in
                let type = data[index]
                SeperatorLineView(padHorizontal: false)
                HStack(spacing: 50.asDeviceWidth){
                    Text("#\(index + 1)")
                        .foregroundColor(.white)
                        .font(.inter(16.asDeviceWidth, .regular))
                        .textCase(.none)
                    
                    Text(type.time)
                        .foregroundColor(.white)
                        .font(.inter(16.asDeviceWidth, .regular))
                        .textCase(.none)
                    
                    HStack(spacing: 5){
                        if type.stageImage != ""{
                            Image(type.stageImage, bundle: nil)
                                .aspectRatio(contentMode: .fit)
                                .cornerRadius(10)
                        }
                        
                        Text(type.stageTitle)
                            .foregroundColor(.white)
                            .font(.inter(16.asDeviceWidth, .regular))
                            .textCase(.none)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }.padding(.leading, 30.asDeviceWidth)
                }
            }
            SeperatorLineView(padHorizontal: false)
        }
    }
}

#Preview {
    CardiacArrestLogsView(codeLogsArray: [])
}
