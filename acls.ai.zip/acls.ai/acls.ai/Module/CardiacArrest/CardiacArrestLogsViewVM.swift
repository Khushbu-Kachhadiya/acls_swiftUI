//
//  CardiacArrestLogsViewVM.swift
//  acls.ai
//
//  Created by Developer on 05/06/24.
//

import Foundation

struct CodeLogsModel: Codable, Hashable{
    var time: String
    var stageTitle: String
    var stageImage: String = ""
    
    private static var lastID: Int = 0
    
    init(time: String, stageTitle: String, stageImage: String = "") {
        self.time = time
        self.stageTitle = stageTitle
        self.stageImage = stageImage
    }
}

@MainActor
final class CardiacArrestLogsViewVM: ObservableObject {
    @Published var navigateToView: Bool = false
}
