//
//  CardiacArrestView.swift
//  acls.ai
//
//  Created by Developer1 on 05/04/24.
//

import SwiftUI

extension NSNotification {
    static let ResetCodeLogs = Notification.Name.init("ResetCodeLogs")
}

struct CardiacArrestView: View {
    @State var title:String = ""
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @StateObject var viewModel: CardiacArrestViewVM = CardiacArrestViewVM()
    
    @State var hideControlPanelTask: DispatchWorkItem?
    @State var reader: ScrollViewProxy?
    
       
//    @State var degrees: Double = 0

    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack{
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal,20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title:title) {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                if !viewModel.showLogs{
                    stepsView
                }else{
                    logsView
                }
            }
//            .rotation3DEffect(.degrees(degrees), axis: (x: 0, y: 1, z: 0))
        }
        .navigationDestination(isPresented: $viewModel.shouldShowInfo) {
            CardiacArrestInfoView()
        }
        .navigationBarBackButtonHidden()
//        .onReceive(NotificationCenter.default.publisher(for: NSNotification.ResetCodeLogs), perform: { _ in
//            viewModel.referesh()
//        })
    }
    
    private var stepsView:some View{
        VStack{
            timerView
            SeperatorLineView()
            if viewModel.shouldShowCRPView {
                cprView
            }
            HStack {
                Button {
                    viewModel.referesh()
                    withAnimation {
                        reader?.scrollTo(0, anchor: .top)
                    }
                } label: {
                    AppImages.appIcn_refresh
                }
                .padding(.leading, 22.asDeviceHeight)
                Spacer()
                
                Button {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        viewModel.showLogs.toggle()
//                        degrees += 360
                    }
                } label: {
                    AppImages.appIcn_log
                }
                .padding(.trailing, 22.asDeviceHeight)
            }
            progressLoaderView.padding(.bottom, 20)
            stpesScrollView.padding(.bottom,20)
//                    SeperatorLineView()
//                    AddOptionsView(title: CardiacArrestOptions.CPR_Quality.description)
//                    SeperatorLineView()
//                    AddOptionsView(title: CardiacArrestOptions.Medication.description)
//                    SeperatorLineView().padding(.bottom,20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        .background(.appBlackLight)
        .cornerRadius(10)
        .padding(.horizontal,20)
    }
    
    private var timerView:some View{
        HStack{
//            Image.appIcn_volume
//                .frame(width: 24.asDeviceWidth,height: 24.asDeviceWidth)
            Text(viewModel.timeString())
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(20.asDeviceWidth, .bold))
            Spacer()
            HStack(spacing: 20){
                if !viewModel.timerIsRunning{
                    AppCommonButton(steps: $viewModel.cardiacArray, title: "start", backgroundColor: .appRedColor) {
                        viewModel.timerIsRunning.toggle()
                        if viewModel.timerIsRunning {
                            viewModel.startTimer()
                        } else {
                            viewModel.stopTimer()
                        }
                    }
                }else{
                    AppCommonButton(steps: $viewModel.cardiacArray, title: "stop", backgroundColor: .appRedColor) {
                        viewModel.timerIsRunning.toggle()
                        if viewModel.timerIsRunning {
                            viewModel.startTimer()
                        } else {
                            viewModel.stopTimer()
                        }
                    }
                }
                AppImages.infoGreen
                    .frame(width: 20.asDeviceWidth,height: 20.asDeviceWidth)
                    .onTapGesture {
                        viewModel.shouldShowInfo = true
                    }
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
    }
    
    private var progressLoaderView: some View{
        CircularProgressView(progress: viewModel.progress)
            .frame(width: 200.asDeviceWidth,height: 200.asDeviceWidth)
    }
    
    private var cprView: some View{
        HStack{
            HStack{
                Text("0")
                    .foregroundColor(.white)
                    .font(.inter(14.asDeviceWidth, .bold))
                Text("CPR : 00:00")
                    .foregroundColor(.gray)
                    .font(.inter(14.asDeviceWidth, .medium))
            }
            Spacer()
            HStack{
                Text("0")
                    .foregroundColor(.white)
                    .font(.inter(14.asDeviceWidth, .bold))
                Text("EPR : 00:00")
                    .foregroundColor(.gray)
                    .font(.inter(14.asDeviceWidth, .medium))
            }
            Spacer()
            HStack{
                Text("0")
                    .foregroundColor(.white)
                    .font(.inter(14.asDeviceWidth, .bold))
                Image.appIcn_lightning
                    .frame(width: 16.asDeviceWidth,height: 16.asDeviceWidth)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal)
        .padding(.vertical,5)
    }
    
    private var stpesScrollView: some View{
        ZStack{
            ScrollView{
                ScrollViewReader { reader in
                    VStack(spacing: 0){
                        //1st step
                        Text("").frame(height: 30.asDeviceHeight)
                        ForEach(0..<viewModel.cardiacArray.count, id: \.self){ index in
                            TitleWithRoundStepper(steps: $viewModel.cardiacArray, index: index) {
                                if viewModel.timerIsRunning {
                                    updateProgress(index: index, reader: reader)
                                } else{
                                    self.viewModel.showsAlert.toggle()
                                }
                            }
                            .id(index)
                            .alert(isPresented: self.$viewModel.showsAlert) {
                                Alert(title: Text("Please start timer before starting the process."))
                            }
                            .onAppear {
                                self.reader = reader
                            }
                            
//                            DescriptionWithLineStepper(index: index) { btnTitle in
//                                updateProgress(index: index, reader: reader)
//                                if btnTitle == ButtonType.yes.rawValue{
//                                    print(btnTitle)
//                                }else if btnTitle == ButtonType.start.rawValue{
//                                    viewModel.cardiacArray[index].isStartButtonHidden = true
//                                    viewModel.cardiacArray[index].timer = "00:00"
//                                }else{
//                                    print(btnTitle)
//                                }
//                            }
//
//                            .environmentObject(viewModel)
                        }
                        //                        Text("").frame(height: 30.asDeviceHeight)
                        GeometryReader{ proxy in
                            Color.clear
                                .onChange(of: proxy.frame(in: .global).minY) { offsetY in
                                    hideControlPanelTask?.cancel()
                                    self.hideControlPanelTask = DispatchWorkItem {
                                        withAnimation {
                                            reader.scrollTo(viewModel.currentIndex, anchor: .center)
                                        }
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.02, execute: hideControlPanelTask!)
                                }
                        }
                    }
                }
                
            }
        }
        .innerShadow(color: .appBlackLightColor,radius: 0.11)
    }
    
    private var logsView: some View{
        VStack{
            HStack{
                Button {
                    viewModel.referesh()
//                    NotificationCenter.default.post(name: NSNotification.ResetCodeLogs, object: nil)
                } label: {
                    Text("Reset")
                        .textCase(.uppercase)
                        .foregroundColor(.appBlackLight)
                        .font(.inter(19.asDeviceWidth, .bold))
                }
                .padding(.horizontal)
                .frame(height: 55.asDeviceHeight)
                .frame(minWidth: 80)
                .background(Color.appRedColor)
                .cornerRadius(8)
                .padding([.top, .leading], 22.asDeviceHeight)
                
                Spacer()
                Image.systemClose
                    .font(.title)
                    .padding([.top, .trailing], 22.asDeviceHeight)
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.1)) {
                            viewModel.showLogs.toggle()
//                            degrees -= 360
                        }
                    }
            }
            
            Text("Code Logs")
                .foregroundColor(.white)
                .font(.inter(18.asDeviceWidth, .bold))
                .textCase(.none)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.top,10)
            
            if self.viewModel.codeLogsArray.count > 0{
                codeLogsView(data: self.viewModel.codeLogsArray)
                    .padding(20)
            }else{
                SeperatorLineView(padHorizontal: false)
                Text("Not logs added yet.")
                    .foregroundColor(.white)
                    .font(.inter(18.asDeviceWidth, .semibold))
                    .textCase(.none)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top,10)
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        .background(.appBlackLight)
        .cornerRadius(10)
        .padding(.horizontal,20)
    }
    
    @ViewBuilder
    private func codeLogsView(data: [CodeLogsModel]) -> some View {
        VStack(spacing: 10){
            ForEach(0..<data.count, id: \.self){ index in
                let type = data[index]
                SeperatorLineView(padHorizontal: false)
                HStack(spacing: 50.asDeviceWidth){
                    Text("#\(index + 1)")
                        .foregroundColor(.white)
                        .font(.inter(16.asDeviceWidth, .regular))
                        .textCase(.none)
                    
                    Text(type.time)
                        .foregroundColor(.white)
                        .font(.inter(16.asDeviceWidth, .regular))
                        .textCase(.none)
                    
                    HStack(spacing: 5){
                        if type.stageImage != ""{
                            Image(type.stageImage, bundle: nil)
                                .aspectRatio(contentMode: .fit)
                                .cornerRadius(10)
                        }
                        
                        Text(type.stageTitle)
                            .foregroundColor(.white)
                            .font(.inter(16.asDeviceWidth, .regular))
                            .textCase(.none)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }.padding(.leading, 30.asDeviceWidth)
                }
            }
            SeperatorLineView(padHorizontal: false)
        }
    }
}

#Preview {
    CardiacArrestView(title: "Dynamic Title")
}

//MARK: - User Function
extension CardiacArrestView {
    func updateProgress(index: Int, reader: ScrollViewProxy){
        if viewModel.cardiacArray[index].isPreviousStepCompleted == true,viewModel.cardiacArray[index].isCurrentStepCompleted == false {
            viewModel.cardiacArray[index].isCurrentStepCompleted = true
            if index < viewModel.cardiacArray.count - 1{
                viewModel.cardiacArray[index + 1].isPreviousStepCompleted = true
                if viewModel.cardiacArray[index].stepLogTitle != nil{
                    viewModel.addLogs(stageTitle: viewModel.cardiacArray[index].stepLogTitle ?? "",stageImage: viewModel.cardiacArray[index].titleImage ?? "")
                }
            }else{
                if viewModel.cardiacArray[index].isLastStep{
                    viewModel.timerIsRunning.toggle()
                    viewModel.stopTimer()
                    viewModel.addLogs(stageTitle: "Ended",stageImage: viewModel.cardiacArray[index].titleImage ?? "")
                }
            }
            withAnimation {
                viewModel.updateProgressAsPerStepsCompleted()
                if index < viewModel.cardiacArray.count - 1{
                    reader.scrollTo(index + 1, anchor: .center)
                    viewModel.currentIndex = index + 1
                }
            }
        }
    }
}
