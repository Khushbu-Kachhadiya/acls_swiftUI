//
//  HomeView.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import SwiftUI

struct HomeView: View {
    private let adaptiveColumn = [GridItem(.adaptive(minimum: 185.asDeviceHeight))]
    @StateObject var viewModel: HomeViewVM = HomeViewVM()
    
    @StateObject var entitlementManager: EntitlementManager = EntitlementManager()
    @StateObject var subscriptionsManager: SubscriptionsManager = SubscriptionsManager(entitlementManager: EntitlementManager())

    //MARK: - Body
    var body: some View {
        ZStack{
            Color.appThemeColor
                .ignoresSafeArea()
            VStack(alignment: .leading){
                HeaderTitleAndProfileNavigationView(showButtons: true)
                    .padding(.horizontal,20.asDeviceWidth)
                gridView
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            //MARK: - To delete the data from the keychain For testing purpose
//            KeychainStorageManager.delete_isAgreeLegalDisclaimer()
//            KeychainStorageManager.delete_isUserSubscribed()
//            KeychainStorageManager.delete_freeTrialStartDate()
//            KeychainStorageManager.delete_freeTrialStartDate()
        }
    }
    
    private var gridView: some View{
        ScrollView{
            LazyVGrid(columns: adaptiveColumn, spacing: 30.asDeviceHeight) {
                ForEach(viewModel.homeCategoryList, id: \.self) { type in
                    homeCategoryView(data: type.model)
                        .onTapGesture {
                            let freeTrialStartDate = Date(milliseconds: KeychainStorageManager.freeTrialStartDate)
                            let isFreeTrialCompeled = freeTrialStartDate.IsDateAfter3Days()
                            if isFreeTrialCompeled{
                                //To present the view
                                viewModel.isPresetSubscriptionView.toggle()
                            }else{
                                //To push the view
                                viewModel.navigateToCategoryView.toggle()
                            }
                            
                            viewModel.title = type.model.description
                            viewModel.currentCategoryType = type
                        }
                }
            }
        }
        .padding(.horizontal,20.asDeviceWidth)
        .padding(.top,80.asDeviceHeight)
        .scrollDisabled(true)
        .navigationDestination(isPresented: $viewModel.navigateToCategoryView) {
            switch viewModel.currentCategoryType {
            case .bardycardia:
                BardycardiaView(title: viewModel.title)
            case .postCardiaArrestCare:
                PostCardiaArrestCareView(title: viewModel.title)
            case .tachycardia:
                TachycardiaView(title: viewModel.title)
            case .cardiaArrest:
//                UserSettings.testKeychain = true
                CardiacArrestView(title: viewModel.title)
            }
        }
        .fullScreenCover(isPresented: $viewModel.isPresetSubscriptionView) {
            PaymentView()
                .transition(.move(edge: .trailing))
                .zIndex(1)
                .environmentObject(entitlementManager)
                .environmentObject(subscriptionsManager)
                .task {
                    await subscriptionsManager.updatePurchasedProducts()
                }
        }
    }
    
    @ViewBuilder
    private func homeCategoryView(data: HomeModel) -> some View {
        VStack(spacing: 20.asDeviceHeight){
            RoundedRectangle(cornerRadius: 10).fill(.appBlackLight)
                .overlay {
                    Image(data.image , bundle: nil)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .background(.appBlackLight)
                        .cornerRadius(10)
                        .padding(15)
                }
                .frame(width: 185.asDeviceWidth, height: 185.asDeviceWidth, alignment: .center)

            Text(data.description )
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .frame(width: 185.asDeviceWidth, height: 60.asDeviceHeight,alignment: .top)
                .font(.inter(20, .bold))
        }
    }
}

#Preview {
    HomeView()
}
