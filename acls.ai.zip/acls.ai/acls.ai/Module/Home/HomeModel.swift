//
//  HomeModel.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import SwiftUI

struct HomeModel: Codable, Hashable {
    let image: String
    let description: String
    
    init(image: String, description: String) {
        self.image = image
        self.description = description
    }
}
