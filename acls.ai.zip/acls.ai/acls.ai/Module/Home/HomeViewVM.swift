//
//  HomeViewVM.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import Foundation
import SwiftUI

enum HomeModelType {
    case bardycardia
    case postCardiaArrestCare
    case tachycardia
    case cardiaArrest
        
    var model: HomeModel {
        switch self {
        case .bardycardia:
            HomeModel(image: "app.icn.bradycardia", description: "Bradycardia")
        case .postCardiaArrestCare:
            HomeModel(image: "app.icn.postcardiac_arrestCare", description: "Post Cardiac Arrest Care")
        case .tachycardia:
            HomeModel(image: "app.icn.tachycardia", description: "Tachycardia")
        case .cardiaArrest:
            HomeModel(image: "app.icn.cardiac_arrest", description: "Cardiac Arrest")
        }
    }
}

@MainActor
final class HomeViewVM: ObservableObject {
    @Published var navigateToProfileView: Bool = false
    @Published var navigateToCategoryView: Bool = false
    @Published var currentCategoryType: HomeModelType = .tachycardia
    @Published var title: String = ""
    @Published var isPresetSubscriptionView: Bool = false
    
    var homeCategoryList: [HomeModelType] = [
        .cardiaArrest,
        .tachycardia,
        .bardycardia,
        .postCardiaArrestCare
    ]
}
