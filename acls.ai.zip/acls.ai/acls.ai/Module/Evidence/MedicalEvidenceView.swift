import SwiftUI

struct MedicalEvidenceView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    @State var navigateToView: Bool = false
    
    struct Title: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(16, .bold))
                .padding(.horizontal, 8)
                .padding(.top, 16)
        }
    }
    
    struct Description: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(14, .regular))
                .multilineTextAlignment(.leading)
                .padding(.top,1)
                .padding(.horizontal, 8)
        }
    }

    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading) {
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal, 20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title: "Medical Evidence") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                    
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading) {
                        Title(string: K.title)
                        SeperatorLineView(padHorizontal: false)
                        
                        Title(string: K.header1)
                        
                        Title(string: K.header2)
                        
                        Title(string: K.header3)
                        
                        Title(string: K.header4)
                        
                        Title(string: K.header5)
                        
                        Title(string: K.header6)
                        
                        Title(string: K.header7)
                        
                        Title(string: K.header8)
                        
                        Spacer()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .background(.appBlackLight)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview {
    BardycardiaInfoView()
}

private extension MedicalEvidenceView {
    enum K {
        static var title = "Evidence"
        
        static var header1 = """
        1. Merchant Raina M., Topjian Alexis A.,
        Panchal Ashish R., et al. Part 1: Executive
        Summary: 2020 American Heart Association
        Guidelines for Cardiopulmonary Resuscitation and Emergency
        Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000918
        """
               
        static var header2 = """
        2. Magid David J., Aziz Khalid, Cheng Adam, et al. Part 2: Evidence Evaluation and Guidelines Development: 2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000898
        """
        static var descp2 = """
        Usual infusion rate is 5-20 mcg/kg per minute.
        Titrate to patient response; taper slowly.
        """
        
        static var header3 = """
        3. Panchal Ashish R., Bartos Jason A.,
        Cabañas José G., et al. Part 3: Adult Basic and Advanced Life Support: 2020 American
        Heart Association Guidelines for
        Cardiopulmonary Resuscitation and
        Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000916
        """
        
        static var header4 = """
        4. Topjian Alexis A., Raymond Tia T., Atkins Dianne, et al.
        Part 4: Pediatric Basic and Advanced Life Support: 2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000916
        """
        
        static var header5 = """
        5. Topjian Alexis A., Raymond Tia T., Atkins Dianne, et al. Part 4: Pediatric Basic and Advanced Life Support: 2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000901
        """
        
        static var header6 = """
        6. Aziz Khalid, Lee Henry C., Escobedo Marilyn
        B., et al. Part 5: Neonatal Resuscitation:
        2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000902
        """
        
        static var header7 = """
        7. Cheng Adam, Magid David J., Auerbach Marc, et al. Part 6: Resuscitation Education Science: 2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000903
        """
        
        static var header8 = """
        8. Berg Katherine M., Cheng Adam, Panchal Ashish R., et al. Part 7: Systems of Care:
            2020 American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. Circulation.
        doi: 10.1161/CIR.0000000000000899
        """
    }
}
