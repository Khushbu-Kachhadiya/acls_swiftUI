import Foundation

enum TachycardiaStates {
    static var start = StepModel(
        title: "Assess Appropriateness for clinical condition.",
        subTitle: "Heart rate Typical ≥ 150/min if tachyarrhythmia. \nGive oxygen & attach\nmonitor defribllator",
        isPreviousStepCompleted: true
    )
    
    static var identification = StepModel(
        title: "Identify and treat underlying cause",
        subTitle: """
        Maintain patient airway; assist breathing as necessary \n
        Oxygen (if hypoxemic) \n
        Cardiac Monitor to identify rhythm; monitor blood pressure and oximetry \n
        IV access \n
        12-lead ECG, if available \n
        """
    )
    
    static var persistentTachya = StepModel(
        title: "Persistent Tachyarrhythmia causing",
        subTitle: """
        Hypertension? \n
        Acutely altered mental status? \n
        Signs of shock? \n
        Ischemic chest discomfort? \n
        Acute heart failure?
        """,
        buttonTypes: [.no, .yes],
        yesStage:  ButtonModal(Nextstage: persistentTachyaYesSteps),
        noStage: ButtonModal(Nextstage: persistentTachyaNoSteps)
    )
    
    static var syncCardio = StepModel(
        title: "Synchronized Cardioversion",
        subTitle: """
        Consider Sedation \n
        If regular narrow complex, consider adenosine
        """
    )
    
    static var refactory = StepModel(
        title: "If refactory, consider",
        subTitle: """
        Underlying cause \n
        Need to increase energy level for next cardioversion \n
        Addition of anti-arrhythmic drug \n
        Expert consultation
        """,
        isLastStep: true
    )
    
    static var persistentTachyaYesSteps = [syncCardio, refactory]
    
    static var qrs = StepModel(
        title: "Wide QRS? ≥0.12 second",
        subTitle: """
        Consider Sedation \n
        If regular narrow complex, consider adenosine
        """,
        buttonTypes: [.no, .yes],
        yesStage:  ButtonModal(Nextstage: [qrsYesStep1, refactory], isSelected: false),
        noStage:  ButtonModal(Nextstage: [qrsNoStep], isSelected: false)
    )
    
    static var qrsNoStep = StepModel(
        title: nil,
        subTitle: """
        Vagal maneuvers (if regular) \n
        Adenosine (if regular) \n
        β-Blocker or calcium channel blocker \n
        Consider expert consultation
        """,
        isLastStep: true
    )
    
    static var qrsYesStep1 = StepModel(
        title: "Consider",
        subTitle: """
        Adenoise only if regular and monomorphic \n
        Antiarrhythmic infusion \n
        Expert consultation
        """
    )
    
    static var persistentTachyaNoSteps = [qrs, Globals.unknownStep]
    
    static var stage0 = [
        start,
        identification,
        persistentTachya,
        Globals.unknownStep
    ]
}
