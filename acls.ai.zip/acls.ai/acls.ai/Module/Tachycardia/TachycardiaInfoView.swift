import SwiftUI

struct TrachycardiaInfoView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    
    struct Title: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(16, .bold))
                .padding(.horizontal, 8)
                .padding(.top, 16)
        }
    }
    
    struct Description: View {
        let string: String
        var body: some View {
            Text(string)
                .foregroundColor(.white)
                .font(.inter(14, .regular))
                .multilineTextAlignment(.leading)
                .padding(.top,1)
                .padding(.horizontal, 8)
        }
    }

    var body: some View {
        ZStack(alignment: .top){
            Color.appThemeColor
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading){
                    HeaderTitleAndProfileNavigationView()
                        .padding(.horizontal, 20.asDeviceWidth)
                    
                    HeaderNavigationTitleWithBackButton(title: "Tachycardia") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
                    
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading) {
                        Title(string: K.title)
                        SeperatorLineView(padHorizontal: false)
                        
                        Title(string: K.header1)
                        Description(string: K.descp1)
                        
                        Title(string: K.header2)
                        Description(string: K.descp2)
                        
                        SeperatorLineView(padHorizontal: false)
                        
                        Title(string: K.header3)
                        
                        Title(string: K.header4)
                        Description(string: K.descp4)
                        
                        Title(string: K.header5)
                        Description(string: K.descp5)
                        
                        Title(string: K.header6)
                        Description(string: K.descp6)
                        
                        SeperatorLineView(padHorizontal: false)
                        Spacer()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .background(.appBlackLight)
                .cornerRadius(10)
                .padding(.horizontal,20)
            }
        }
        .navigationBarBackButtonHidden()
    }
}

private extension TrachycardiaInfoView {
    enum K {
        static var title = "Doses/Details"
        
        static var header1 = "Synchronized cardioversion:"
        
        static var descp1 = """
        Refer to your specific device’s recommended energy
        level ot maximize first shock success.
        """
        
        static var header2 = "Adenosine IV dose:"
        
        static var descp2 = """
        First dose: 6mg rapid IV push; follow with NS flush. \n
        Second dose: 12 mg if required.
        """
        
        static var header3 = "Antiarrhythmic Infusions for Stable Wide-QRS Tachycardia"
        
        static var header4 = "Procainamide IV dose:"
        static var descp4 = """
        20-50 mg/min until arrhythmia suppressed,
        hypotension ensues, QRS duration increase >50% \n
        Maintenance infusion: 1-4 mg/min. \n
        Avoid if prolonged QT or CHF.
        """
        
        static var header5 = "Amiodarone IV dose:"
        static var descp5 = """
        First dose: 150 mg over 10 minutes. \n
        Repeat as needed if VT recurs. \n
        Follow by maintenance infusion of 1 mg/min for first 6 hours
        """
        
        static var header6 = "Amiodarone IV dose:"
        static var descp6 = """
        100mg (1.5 mg/kg) over 5 minutes. Avoid if
        prolonged QT.
        """
    }
    
}
