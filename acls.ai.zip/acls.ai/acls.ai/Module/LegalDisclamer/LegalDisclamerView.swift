//
//  LegalDisclamerView.swift
//  acls.ai
//
//  Created by iMac on 07/06/24.
//
//
import SwiftUI

struct LegalDisclamerView: View {
    @Environment(\.presentationMode) var viewPresentMode: Binding<PresentationMode>
    var shouldShowAgreeButton = true
    @State var isAgree : Bool = false
    
    var body: some View {
        VStack(alignment:.leading){
            VStack(alignment: .leading){
                HeaderTitleAndProfileNavigationView()
                    .padding(.horizontal,20.asDeviceWidth)
                
                if !shouldShowAgreeButton {
                    HeaderNavigationTitleWithBackButton(title: "Legal Disclaimer") {
                        viewPresentMode.wrappedValue.dismiss()
                    }
                }
            }
            
            
            Text("Legal Disclaimer")
                .font(.title2)
                .bold()
            
            ScrollView {
                VStack(alignment:.leading){
                    Text("ACLS.AI TERMS OF USE AND USER AGREEMENT (iOS)\n")
                        .font(.body)
                        .bold()
                    getTextView(from: TermSection.termsOfUse)
                    +
                    Text("CONTACT INFORMATION:\n\n")
                        .font(.body)
                        .foregroundColor(.white)
                        .fontWeight(.semibold)
                    +
                    Text("Individual questions and complaints should be directed to the following:  Indra Labs, LLC Program Administrator, 10-04 Bush Place, FairLawn NJ, 07410, or email to ")
                        .font(.body)
                        .foregroundColor(.white)
                    +
                    Text("admin@indralabz.")
                        .font(.body)
                        .foregroundColor(.white)
                        .fontWeight(.semibold)
                        .underline()
                    +
                    Text("com")
                        .font(.body)
                        .foregroundColor(.white)
                        .fontWeight(.semibold)
                        .underline()
                }
                .multilineTextAlignment(.leading)
                .padding(.top,25.asDeviceHeight)
            }
           
            if shouldShowAgreeButton {
                Button{
                    KeychainStorageManager.isAgreeLegalDisclaimer = true
                    isAgree = true
                }label: {
                    Text("I ACCEPT")
                        .bold()
                        .foregroundStyle(Color.appBlackLight)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.appRedColor)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .padding(.top)
                }
                Spacer()
            }
        }
        .foregroundStyle(.white)
        .padding(.horizontal,20.asDeviceWidth)
        .background(Color.appThemeColor)
        .navigationDestination(isPresented: $isAgree) {
            PaymentView()
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview {
    LegalDisclamerView()
}
//function
extension LegalDisclamerView{
    // Function to generate the Text view
    func getTextView(from segments: [TermSection]) -> Text {
        var resultText = Text("")
        for section in segments {
            resultText = resultText + Text("\(section.section)\n\n").font(.title2).bold()
            for segment in section.content  {
                let textPart = Text("\(segment.0)\n\n").fontWeight(segment.1)
                    .font(segment.2)
                resultText = resultText + textPart
            }
            
        }
        return resultText
    }
}


//import SwiftUI
//
//struct view: View {
//    var body: some View {
//        ScrollView {
//            VStack(alignment: .leading) {
//                getTextView(from: TermSection.termsOfUse)
//                    .padding()
//            }
//        }
//    }
//    
//    
//    
//    // Function to generate the Text view
//    func getTextView(from segments: [TermSection]) -> Text {
//        var resultText = Text("")
//        for section in segments {
//            for segment in section.content  {
//                let textPart = Text(segment.0).fontWeight(segment.1)
//                    .font(segment.2)
//                resultText = resultText + textPart
//            }
//            
//        }
//        return resultText
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        view()
//    }
//}

