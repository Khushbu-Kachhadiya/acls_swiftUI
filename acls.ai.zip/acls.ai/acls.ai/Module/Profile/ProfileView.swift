//
//  ProfileView.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        ZStack{
            Color.appThemeColor
                .ignoresSafeArea()
            VStack(alignment: .center, spacing: 20){
//                AppCommonButton(title: "start", backgroundColor: .appRedColor) {
//                    print("Start button tap")
//                }
//                
//                AppCommonButton(title: "yes", backgroundColor: .appLimeColor) {
//                    print("Start button tap")
//                }
//                AppCommonButton(title: "no", backgroundColor: .appGrayColor) {
//                    print("Start button tap")
//                }
//                AppCommonButton(title: "start", backgroundColor: .appSkyColor) {
//                    print("Start button tap")
//                }
            }
        }
    }
}

#Preview {
    ProfileView()
}
