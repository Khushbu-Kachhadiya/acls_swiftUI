//
//  Ext+Date.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import Foundation

extension Date {
    func toString(format: String = "EEEE, dd MMM") -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
    
    func IsDateAfter3Days() -> Bool{
        var calendar = Calendar.current
        calendar.locale = .current
        calendar.timeZone = .current
        if let diff = calendar.dateComponents([.day], from: self, to: Date()).day, diff > 2 {
            print("Date is after 3 days.")
            return true
        }else{
            print("Date is not after 3 days.")
            return false
        }
    }
    
    var millisecondsSince1970:Int {
        Int((self.timeIntervalSince1970)*1000)
    }
    
    init(milliseconds:Int) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }
    
//    func getDateAfter3Days() -> Date{
//        var calendar = Calendar.current
//        calendar.locale = .current
//        calendar.timeZone = .current
//        var dateComponents = DateComponents()
//        dateComponents.day = 3
//        let dateAfter3Days = calendar.date(byAdding: dateComponents, to: self)
//        return dateAfter3Days ?? Date()
//    }
}
