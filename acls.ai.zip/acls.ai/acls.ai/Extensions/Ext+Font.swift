//
//  Ext+Font.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import SwiftUI

extension Font {
    static func inter(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Self {
        switch weight {
        case .black: return .custom("Inter-Black", size: size.asDeviceWidth)
        case .bold: return .custom("Inter-Bold", size: size.asDeviceWidth)
        case .heavy: return .custom("Inter-ExtraBold", size: size.asDeviceWidth)
        case .ultraLight: return .custom("Inter-ExtraLight", size: size.asDeviceWidth)
        case .light: return .custom("Inter-Light", size: size.asDeviceWidth)
        case .medium: return .custom("Inter-Medium", size: size.asDeviceWidth)
        case .regular: return .custom("Inter-Regular", size: size.asDeviceWidth)
        case .semibold: return .custom("Inter-SemiBold", size: size.asDeviceWidth)
        case .thin: return .custom("Inter-Thin", size: size.asDeviceWidth)
        default: fatalError("\(Font.self) \(weight) is not yet supported")
        }
    }
}
