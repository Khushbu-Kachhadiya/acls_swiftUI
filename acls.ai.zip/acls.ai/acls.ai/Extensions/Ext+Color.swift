//
//  Ext+Color.swift
//  acls.ai
//
//  Created by Developer1 on 02/04/24.
//

import SwiftUI

extension Color {
    static let appThemeColor = ThemeColors.appblack
    static let appLimeColor = ThemeColors.applime
    static let appGrayColor = ThemeColors.appgray
    static let appBlackLightColor = ThemeColors.appblacklight
    static let appRedColor = ThemeColors.appred
    static let appSkyColor = ThemeColors.appsky
    static let appLineGrayColor = ThemeColors.applinegrayColor
}

struct ThemeColors{
    static let applime = Color("app.lime")
    static let appblack = Color("app.black")
    static let appgray = Color("app.gray")
    static let appblacklight = Color("app.black.light")
    static let appred = Color("app.red")
    static let appsky = Color("app.sky")
    static let applinegrayColor = Color("app.line.gray")
}
