//
//  Ext+Image.swift
//  acls.ai
//
//  Created by Developer1 on 02/04/24.
//

import SwiftUI

extension Image {
    static let appProfile = AppImages.appProfile
    static let appIcn_bradycardia = AppImages.appIcn_bradycardia
    static let appIcn_cardiac_arrest = AppImages.appIcn_cardiac_arrest
    static let appIcn_postcardiac_arrestCare = AppImages.appIcn_postcardiac_arrestCare
    static let appIcn_tachycardia = AppImages.appIcn_tachycardia
    static let appIcn_arrowright_black = AppImages.appIcn_arrowright_black
    static let appIcn_arrowleft_white = AppImages.appIcn_arrowleft_white
    static let appIcn_info = AppImages.appIcn_info
    static let appIcn_volume = AppImages.appIcn_volume
    static let appIcn_lightning = AppImages.appIcn_lightning
    static let appIcn_plus = AppImages.appIcn_plus
    static let appIcn_minus = AppImages.appIcn_minus
    static let appIcn_round_lime = AppImages.appIcn_round_lime
    static let appIcn_round_gray = AppImages.appIcn_round_gray
    static let appIcn_round_lime_true = AppImages.appIcn_round_lime_true
    static let appIcn_epinephrine = AppImages.appIcn_epinephrine
    static let appIcn_refresh = AppImages.appIcn_refresh
    static let appIcn_checkmark = AppImages.appIcn_checkmark
    static let appIcn_log = AppImages.appIcn_log
    static let appIcn_close = AppImages.appIcn_close
    static let systemClose = AppImages.systemClose
}

struct AppImages {
    static let appProfile = Image("app.icn.profile")
    static let appIcn_bradycardia = Image("app.icn.bradycardia")
    static let appIcn_cardiac_arrest = Image("app.icn.cardiac_arrest")
    static let appIcn_postcardiac_arrestCare = Image("app.icn.postcardiac_arrestCare")
    static let appIcn_tachycardia = Image("app.icn.tachycardia")
    static let appIcn_arrowright_black = Image("app.icn.arrowright_black")
    static let appIcn_arrowleft_white = Image("app.icn.arrowleft_white")
    static let appIcn_info = Image("app.icn.info")
    static let appIcn_volume = Image("app.icn.volume")
    static let appIcn_lightning = Image("app.icn.lightning")
    static let appIcn_plus = Image("app.icn.plus")
    static let appIcn_minus = Image("app.icn.minus")
    static let appIcn_round_lime = Image("icn.round.lime")
    static let appIcn_round_gray = Image("icn.round.gray")
    static let appIcn_round_lime_true = Image("icn.round.lime.true")
    static let appIcn_epinephrine = Image("app.icn.epinephrine")
    static let infoGreen = Image("icn.info.green")
    static let appIcn_refresh = Image("app.icn.refresh")
    static let appIcn_checkmark = Image("app.icn.checkmark")
    static let appIcn_log = Image("app.icn.log")
    static let appIcn_close = Image("app.icn.close")
    static let systemClose = Image(systemName: "xmark.circle.fill")
}
