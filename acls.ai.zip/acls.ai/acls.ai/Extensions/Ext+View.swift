//
//  Ext+View.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import SwiftUI

extension View {
    /// Apply a custom border to the view.
    /// - Parameters:
    ///   - color: The color of the border.
    ///   - width: The width of the border.
    func customBorder(cornerRadius: CGFloat, color: Color, width: CGFloat) -> some View {
        self
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius.asDeviceHeight)
                    .stroke(color, lineWidth: width)
            )
    }
    
    func padding(_ edges: Edge.Set = .all, _ paddingType: PaddingType) -> some View {
        padding(edges, paddingType.value)
    }
    
    func customFrame(width: FrameType? = nil, height: FrameType? = nil, alignment: Alignment = .center) -> some View {
        frame(width: width?.value.asDeviceWidth, height: height?.value.asDeviceHeight, alignment: alignment)
    }
    
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
    
    func innerShadow(color: Color, radius: CGFloat = 0.1) -> some View {
        modifier(InnerShadow(color: color, radius: min(max(0, radius), 1)))
    }
}

private struct InnerShadow: ViewModifier {
    var color: Color = .gray
    var radius: CGFloat = 0.1

    private var colors: [Color] {
        [color.opacity(0.85), color.opacity(0.0), .clear]
    }

    func body(content: Content) -> some View {
        GeometryReader { geo in
            content
                .overlay(LinearGradient(gradient: Gradient(colors: self.colors), startPoint: .top, endPoint: .bottom)
                    .frame(height: self.radius * self.minSide(geo)),
                         alignment: .top)
                .overlay(LinearGradient(gradient: Gradient(colors: self.colors), startPoint: .bottom, endPoint: .top)
                    .frame(height: self.radius * self.minSide(geo)),
                         alignment: .bottom)
//                .overlay(LinearGradient(gradient: Gradient(colors: self.colors), startPoint: .leading, endPoint: .trailing)
//                    .frame(width: self.radius * self.minSide(geo)),
//                         alignment: .leading)
//                .overlay(LinearGradient(gradient: Gradient(colors: self.colors), startPoint: .trailing, endPoint: .leading)
//                    .frame(width: self.radius * self.minSide(geo)),
//                         alignment: .trailing)
        }
    }

    func minSide(_ geo: GeometryProxy) -> CGFloat {
        CGFloat(3) * min(geo.size.width, geo.size.height) / 2
    }
}

