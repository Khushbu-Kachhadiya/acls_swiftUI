//
//  CommonViews.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import Foundation
import SwiftUI

struct HeaderTitleAndProfileNavigationView: View {
    @State var navigateToProfileView: Bool = false
    @State var navigateToInfoView: Bool = false
    var showButtons : Bool = false
    

    var body: some View{
        HStack{
            DateView()
            Spacer()
            HStack(alignment: .center, spacing: 13) {
                if showButtons {
                    ProfileButton {
                        navigateToProfileView.toggle()
                    }
                    
                    InfoButton {
                        navigateToInfoView.toggle()
                    }
                    
//                    SubscriptionButton {
//                        navigateToSubscriptionView.toggle()
//                    }
                }
            }
        }
        .navigationDestination(isPresented: $navigateToProfileView) {
            LegalDisclamerView(shouldShowAgreeButton: false)
        }
        .navigationDestination(isPresented: $navigateToInfoView) {
            MedicalEvidenceView()
        }
//        .navigationDestination(isPresented: $navigateToSubscriptionView) {
//            PaymentView()
//                .environmentObject(entitlementManager)
//                .environmentObject(subscriptionsManager)
//                .task {
//                    await subscriptionsManager.updatePurchasedProducts()
//                }
//        }
    }
}

struct HeaderNavigationTitleWithBackButton: View {
    let title: String
    var action: () -> Void
    var body: some View{
        HStack(spacing: 15.asDeviceWidth){
            AppBackButton {
                action()
            }
            Text(title)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.inter(22, .bold))
        }
        .padding(.horizontal,20.asDeviceWidth)
    }
}

struct DateView: View {
    var body: some View {
        Text(Date().toString())
            .textCase(.uppercase)
            .foregroundColor(Color.appGrayColor)
            .font(.inter(12, .medium))
            .frame(height: 40.asDeviceWidth)
    }
}

struct ProfileButton: View {
    let title: String = ""
    var action: () -> Void
    var body: some View {
        Button{
            action()
        } label: {
            Image.appProfile
                .resizable()
                .scaledToFit()
        }
        .customFrame(width: .medium, height: .medium)
    }
}

struct InfoButton: View {
    let title: String = ""
    var action: () -> Void
    var body: some View {
        Button{
            action()
        } label: {
            Image.appIcn_info
                .resizable()
               .scaledToFit()
        }
        .customFrame(width: .medium, height: .medium)
    }
}

struct SubscriptionButton: View {
    let title: String = ""
    var action: () -> Void
    var body: some View {
        Button{
            action()
        } label: {
            Image(systemName: "dollarsign.circle.fill")
                .resizable()
                .padding(3)
               .foregroundStyle(Color.appLime)
        }
        .customFrame(width: .medium, height: .medium)
    }
}

struct AppBackButton: View {
    var action: () -> Void
    var body: some View {
        Button{
            action()
        } label: {
            Image.appIcn_arrowleft_white
        }
    }
}

struct AppCommonButton: View {
    @Binding var steps: [StepModel]
    let title: String
    let backgroundColor: Color
    var index: Int? = nil
    var tapped : Bool = false
    var action: () -> Void
    var body: some View {
        Button {
            if let index {
                if  steps[index].isCurrentStepCompleted == false,
                    steps[index].isPreviousStepCompleted == true {
                    action()
                }
                return
            }
            action()
        } label: {
            Text(title)
                .textCase(.uppercase)
                .foregroundColor(.appBlackLight)
                .font(.inter(19.asDeviceWidth, .bold))
        }
        .padding(.horizontal)
        .frame(height: 55.asDeviceHeight)
        .frame(minWidth: 80)
        .background(tapped ? .appGrayColor : backgroundColor)
        .cornerRadius(8)
    }
}

struct CircularProgressView: View {
    let progress: Double
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .center) {
                Circle()
                    .stroke(
                        Color.appLimeColor.opacity(0.3),
                        lineWidth: 35.asDeviceWidth
                    )
                
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(
                        Color.appLimeColor,
                        style: StrokeStyle(
                            lineWidth: 35.asDeviceWidth,
                            lineCap: .round
                        )
                    )
                    .rotationEffect(.degrees(-90))
                    .animation(.easeOut, value: 0.1)
                
//                if progress == 1.0 {
//                    Text("Rotate to start again").foregroundStyle(.black)
//                        .offset(y: -(geo.size.height/2))
//                        .rotationEffect(.degrees(Double(progress) * 360))
//                        .animation(Animation.easeOut, value: 0.1)
//                }
                
                Image.appIcn_arrowright_black
                    .offset(y: -(geo.size.height/2))
                    .rotationEffect(.degrees(Double(progress) * 360))
                    .animation(Animation.easeOut, value: 0.1)
                
                if progress == 1.0 {
                    Image.appIcn_checkmark
                        .resizable()
                        .scaledToFit()
                        .padding(40)
                        .foregroundColor(Color.green)
                }
            }
        }
    }
}

struct SeperatorLineView: View {
    var padHorizontal = true
    var body: some View{
        Divider()
            .overlay(.appGray)
            .padding(padHorizontal ? .horizontal: [])
    }
}

struct AddOptionsView: View {
    var title:String
    var body: some View{
        VStack{
            HStack{
                Text(title)
                    .foregroundColor(.white)
                    .font(.inter(14.asDeviceWidth, .bold))
                Spacer()
                Image.appIcn_plus
                    .frame(width: 24.asDeviceWidth,height: 24.asDeviceWidth)
            }
            .frame(height: 30.asDeviceHeight)
            .padding(.horizontal)
        }
    }
}

struct TitleWithRoundStepper: View {
    @Binding var steps: [StepModel]
    var index: Int
    var action: () -> Void
    
    @State private var remainingSeconds = 2 * 60 // 2 minutes in seconds
    @State private var timer: Timer? = nil
    
    var body: some View {
        HStack(alignment: .top){
            VStack(spacing: 0){
                Button {
                    if steps[index].buttonTypes == nil {
                        action()
                    }
                } label: {
                    if index < steps.count{
                        if !(steps[index].isCurrentStepCompleted ?? false) {
                            if !(steps[index].isPreviousStepCompleted ?? false){
                                Image.appIcn_round_gray
                                    .resizable()
                                    .frame(width: 24.asDeviceWidth,height: 24.asDeviceWidth)
                            }else{
                                Image.appIcn_round_lime
                                    .resizable()
                                    .frame(width: 24.asDeviceWidth,height: 24.asDeviceWidth)
                            }
                        }else{
                            Image.appIcn_round_lime_true
                                .resizable()
                                .frame(width: 24.asDeviceWidth,height: 24.asDeviceWidth)
                        }
                    }
                }
                
                if index < steps.count{
                    if !steps[index].isLastStep{
                        HorizontalLineView(steps: $steps, index: index)
                    }
                }
            }
           
            // Make both the title and round button tappable
            Button {
                if steps[index].buttonTypes == nil{
                    action()
                }
            } label: {
                if index < steps.count{
                    if let img = steps[index].titleImage{
                        Image(img, bundle: nil)
                    }
                    
                    VStack(alignment: .leading,spacing: 7){
                        if let title = steps[index].title{
                            Text(title )
                                .foregroundColor(.white)
                                .font(.inter(16, .bold))
                            
                        }
                        
                        if let subtitle = steps[index].subTitle{
                            
                            //                            HorizontalLineView(index: index).environmentObject(viewModel)
                            Text(subtitle)
                                .foregroundColor(.white)
                                .font(.inter(14, .regular))
                                .multilineTextAlignment(.leading)
                                .padding(.top,1)
                        }
                        
                        if steps[index].timer != nil, steps[index].isStartButtonHidden == true{
                            Text(timeString(remainingSeconds))
                                .foregroundColor(.appSkyColor)
                                .font(.inter(20.asDeviceWidth, .bold))
                        }
                        
                        if let buttons = steps[index].buttonTypes,steps[index].isStartButtonHidden == false{
                            //                            HorizontalLineView(index: index).environmentObject(viewModel)
                            HStack {
                                ForEach(buttons, id: \.self) { btn in
                                    switch btn {
                                    case .yes:
                                        AppCommonButton(steps: $steps, title: btn.title, backgroundColor: .appLimeColor, index: index, tapped: steps[index].yesStage!.isSelected) {
                                            steps.removeLast()
                                            steps.append(contentsOf:steps[index].yesStage!.Nextstage)
                                            steps[index].yesStage!.isSelected = true
                                            action()
                                        }
                                    case .no:
                                        AppCommonButton(steps: $steps, title: btn.title, backgroundColor: .appRedColor, index: index,tapped: steps[index].noStage!.isSelected) {
                                            steps.removeLast()
                                            steps.append(contentsOf:steps[index].noStage!.Nextstage)
                                            steps[index].noStage!.isSelected = true
                                            action()
                                        }
                                    case .start:
                                        AppCommonButton(steps: $steps, title: btn.title, backgroundColor: .appSkyColor, index: index) {
                                            steps[index].isStartButtonHidden = true
                                            startTimer()
                                        }
                                    case .postCradiac:
                                        AppCommonButton(steps: $steps, title: btn.title,  backgroundColor: .appSkyColor, index: index) {
                                            action()
                                        }
                                    default:
                                        EmptyView()
                                    }
                                }
                                
                                Spacer()
                            }
                        }
                        if let desc = steps[index].description{
                            //                            HorizontalLineView(index: index).environmentObject(viewModel)
                            Text(desc)
                                .foregroundColor(.white)
                                .font(.inter(14, .regular))
                                .multilineTextAlignment(.leading)
                            
                        }
                    }
                    .frame(minHeight: 24.asDeviceWidth)
                }
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            .padding(.bottom)
            Spacer()
                
        }
        .padding(.horizontal)
        .buttonStyle(PlainButtonStyle())
    }
    
    func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if remainingSeconds > 0 {
                remainingSeconds -= 1
            } else {
                timer.invalidate() // Stop the timer
                action()
            }
        }
    }
    
    func timeString(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let seconds = seconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

struct HorizontalLineView: View {
    @Binding var steps: [StepModel]
    var index:Int
    var body: some View {
        HStack{
            Rectangle().frame(width: 24.asDeviceWidth)
                .foregroundColor(.appBlackLightColor)
                .overlay {
                    Rectangle().frame(width: 1.asDeviceWidth,alignment: .center)
                            .foregroundColor((index < steps.count && steps[index].isCurrentStepCompleted ?? false) ? .appLimeColor : .appLineGrayColor)
                }
        }
        .frame(minHeight: (index < steps.count && steps[index].subTitle == nil && steps[index].buttonTypes == nil) ? 50.asDeviceWidth : 0.asDeviceWidth)
    }
}

struct DescriptionWithLineStepper: View {
    @EnvironmentObject var viewModel:CardiacArrestViewVM
    var index : Int
    var action: (String) -> Void
    var body: some View {
        VStack(spacing: 0){
//            if let subtitle = steps[index].subTitle{
//                HStack{
//                    HorizontalLineView(index: index).environmentObject(viewModel)
//                    Text(subtitle)
//                        .foregroundColor(.white)
//                        .font(.inter(14, .regular))
//                        .padding(.bottom,10)
//                    Spacer()
//                }
//            }
//            
//            if let timer = steps[index].timer{
//                HStack{
//                    HorizontalLineView(index: index).environmentObject(viewModel)
//                    Text(timer)
//                        .foregroundColor(.appSkyColor)
//                        .font(.inter(20.asDeviceWidth, .bold))
//                    Spacer()
//                }
//            }
            
//            if let buttons = steps[index].buttonTitles{
//                HStack{
//                    HorizontalLineView(index: index).environmentObject(viewModel)
//                    HStack {
//                        ForEach(buttons, id: \.self) { btn in
//                            switch ButtonType(rawValue: btn) {
//                            case .yes:
//                                AppCommonButton(title: btn, backgroundColor: .appLimeColor, index: index) {
//                                    steps.append(contentsOf:steps[index].yesStage!)
//                                    action(btn)
//                                }
//                            case .no:
//                                AppCommonButton(title: btn, backgroundColor: .appRedColor, index: index) {
//                                    steps.append(contentsOf:steps[index].noStage!)
//                                    action(btn)
//                                }
//                            case .start:
//                              //  if steps[index].isStartButtonHidden == false{
//                                    AppCommonButton(title: btn, backgroundColor: .appSkyColor, index: index) {
//                                        action(btn)
//                                    }
//                               // }
//                            default:
//                                EmptyView()
//                            }
//                        }
//                        
//                        Spacer()
//                    }.frame(maxWidth: .infinity)
//                    .padding(.bottom,20)
//                }
//            }
            
//            if let desc = steps[index].description{
//                HStack{
//                    HorizontalLineView(index: index).environmentObject(viewModel)
//                    Text(desc)
//                        .foregroundColor(.white)
//                        .font(.inter(14, .regular))
//                        .padding(.bottom,10)
//                    Spacer()
//                }
//            }
        }.padding(.horizontal)
    }
}

//struct ButtonWithLineStepper: View {
//    var lineColor: Color
//    var isShowStartBtn: Bool = false
//    var body: some View {
//        HStack{
//            HorizontalLineView(lineColor: lineColor)
//            HStack{
//                if isShowStartBtn{
//                    AppCommonButton(title: "start", backgroundColor: .appSky) {
//                        print("Start tapped..")
//                    }
//                }else{
//                    AppCommonButton(title: "no", backgroundColor: .appRed) {
//                        print("No tapped..")
//                    }
//                    AppCommonButton(title: "yes", backgroundColor: .appLime) {
//                        print("Yes tapped")
//                    }
//                }
//                Spacer()
//            }.padding(.bottom,10)
//        }.padding(.horizontal)
//    }
//}


