//
//  UserDefaultManager.swift
//  acls.ai
//
//  Created by Developer on 19/07/24.
//

import Foundation

//@propertyWrapper
//struct UserDefault<T> {
//    let key: String
//    let defaultValue: T
//
//    init(_ key: String, defaultValue: T) {
//        self.key = key
//        self.defaultValue = defaultValue
//    }
//
//    var wrappedValue: T {
//        get {
//            UserDefaults.standard.object(forKey: key) as? T ?? defaultValue
//        }
//        set {
//            UserDefaults.standard.set(newValue, forKey: key)
//        }
//    }
//}
//
//enum UserdefaultKey{
//    case isAgreeLegalDisclaimer
//    case isUserSubscribed
//    case isUserInFreeTrial
//    case freeTrialStartDate
//    
//    var key : String {
//        switch self {
//        case .isAgreeLegalDisclaimer: "isAgreeLegalDisclaimer"
//        case .isUserSubscribed: "isUserSubscribed"
//        case .isUserInFreeTrial: "isUserInFreeTrial"
//        case .freeTrialStartDate: "freeTrialStartDate"
//        }
//    }
//}
//
//struct UserSettings {
//    @UserDefault(UserdefaultKey.isAgreeLegalDisclaimer.key, defaultValue: false)
//    static var isAgreeLegalDisclaimer: Bool
//    
//    @UserDefault(UserdefaultKey.isUserSubscribed.key, defaultValue: false)
//    static var isUserSubscribed: Bool
//    
//    @UserDefault(UserdefaultKey.isUserInFreeTrial.key, defaultValue: false)
//    static var isUserInFreeTrial: Bool
//    
//    @UserDefault(UserdefaultKey.freeTrialStartDate.key, defaultValue: Date().millisecondsSince1970)
//    static var freeTrialStartDate: Int
//}
