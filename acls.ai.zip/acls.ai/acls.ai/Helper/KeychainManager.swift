//
//  KeychainManager.swift
//  acls.ai
//
//  Created by Developer on 19/07/24.
//

import Foundation
import SwiftUI
import Security

//@propertyWrapper
//struct KeychainStorage<T: Codable> {
//    let key: String
//    let defaultValue: T
//    
//    init(_ key: String, defaultValue: T) {
//        self.key = key
//        self.defaultValue = defaultValue
//    }
//    
//    var wrappedValue: T {
//        get {
//            return readValue() ?? defaultValue
//        }
//        set {
//            saveValue(newValue)
//        }
//    }
//    
//    private func readValue() -> T? {
//        let query: [String: Any] = [
//            kSecClass as String: kSecClassGenericPassword,
//            kSecAttrAccount as String: key,
//            kSecReturnData as String: kCFBooleanTrue!,
//            kSecMatchLimit as String: kSecMatchLimitOne
//        ]
//        
//        var dataTypeRef: AnyObject?
//        let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)
//        
//        guard status == errSecSuccess, let retrievedData = dataTypeRef as? Data else {
//            return nil
//        }
//        
//        return try? JSONDecoder().decode(T.self, from: retrievedData)
//    }
//    
//    private func saveValue(_ value: T) {
//        let data = try? JSONEncoder().encode(value)
//        
//        var query: [String: Any] = [
//            kSecClass as String: kSecClassGenericPassword,
//            kSecAttrAccount as String: key
//        ]
//        
//        if SecItemCopyMatching(query as CFDictionary, nil) == errSecSuccess {
//            let attributesToUpdate: [String: Any] = [kSecValueData as String: data as Any]
//            SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)
//        } else {
//            query[kSecValueData as String] = data
//            SecItemAdd(query as CFDictionary, nil)
//        }
//    }
//    
//    func deleteValue() {
//        let query: [String: Any] = [
//            kSecClass as String: kSecClassGenericPassword,
//            kSecAttrAccount as String: key
//        ]
//        
//        SecItemDelete(query as CFDictionary)
//    }
//    
//    func updateValue(_ value: T) {
//        let data = try? JSONEncoder().encode(value)
//        
//        let query: [String: Any] = [
//            kSecClass as String: kSecClassGenericPassword,
//            kSecAttrAccount as String: key
//        ]
//        
//        let attributesToUpdate: [String: Any] = [kSecValueData as String: data as Any]
//        SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)
//    }
//}

enum KeychainStorageKey{
    case isAgreeLegalDisclaimer
    case isUserSubscribed
    case isUserInFreeTrial
    case freeTrialStartDate
    case testKeychain
    
    var key : String {
        switch self {
        case .isAgreeLegalDisclaimer: "isAgreeLegalDisclaimer"
        case .isUserSubscribed: "isUserSubscribed"
        case .isUserInFreeTrial: "isUserInFreeTrial"
        case .freeTrialStartDate: "freeTrialStartDate"
        case .testKeychain: "testKeychain"
        }
    }
}

//struct KeychainStorageManager {
//    @KeychainStorage(KeychainStorageKey.isAgreeLegalDisclaimer.key, defaultValue: false)
//    static var isAgreeLegalDisclaimer: Bool
//    
//    @KeychainStorage(KeychainStorageKey.isUserSubscribed.key, defaultValue: false)
//    static var isUserSubscribed: Bool
//    
//    @KeychainStorage(KeychainStorageKey.isUserInFreeTrial.key, defaultValue: false)
//    static var isUserInFreeTrial: Bool
//    
//    @KeychainStorage(KeychainStorageKey.freeTrialStartDate.key, defaultValue: Date().millisecondsSince1970)
//    static var freeTrialStartDate: Int
//}


@propertyWrapper
struct KeychainStorage<T: Codable> {
    let key: String
    let defaultValue: T

    init(_ key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }

    var wrappedValue: T {
        get {
            return readValue() ?? defaultValue
        }
        set {
            saveValue(newValue)
        }
    }

    private func readValue() -> T? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: kCFBooleanTrue!,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)

        guard status == errSecSuccess, let retrievedData = dataTypeRef as? Data else {
            return nil
        }

        return try? JSONDecoder().decode(T.self, from: retrievedData)
    }

    private func saveValue(_ value: T) {
        let data = try? JSONEncoder().encode(value)
        
        var query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]

        if SecItemCopyMatching(query as CFDictionary, nil) == errSecSuccess {
            let attributesToUpdate: [String: Any] = [kSecValueData as String: data as Any]
            SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)
        } else {
            query[kSecValueData as String] = data
            SecItemAdd(query as CFDictionary, nil)
        }
    }

    func deleteValue() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]

        SecItemDelete(query as CFDictionary)
    }

    func updateValue(_ value: T) {
        saveValue(value)
    }
}

struct KeychainStorageManager {
    private static var isAgreeLegalDisclaimerStorage = KeychainStorage<Bool>(KeychainStorageKey.isAgreeLegalDisclaimer.key, defaultValue: false)
    private static var isUserSubscribedStorage = KeychainStorage<Bool>(KeychainStorageKey.isUserSubscribed.key, defaultValue: false)
    private static var isUserInFreeTrialStorage = KeychainStorage<Bool>(KeychainStorageKey.isUserInFreeTrial.key, defaultValue: false)
    private static var freeTrialStartDateStorage = KeychainStorage<Int>(KeychainStorageKey.freeTrialStartDate.key, defaultValue: Date().millisecondsSince1970)
    
    static var isAgreeLegalDisclaimer: Bool {
        get { isAgreeLegalDisclaimerStorage.wrappedValue }
        set { isAgreeLegalDisclaimerStorage.wrappedValue = newValue }
    }
    
    static var isUserSubscribed: Bool {
        get { isUserSubscribedStorage.wrappedValue }
        set { isUserSubscribedStorage.wrappedValue = newValue }
    }
    
    static var isUserInFreeTrial: Bool {
        get { isUserInFreeTrialStorage.wrappedValue }
        set { isUserInFreeTrialStorage.wrappedValue = newValue }
    }
    
    static var freeTrialStartDate: Int {
        get { freeTrialStartDateStorage.wrappedValue }
        set { freeTrialStartDateStorage.wrappedValue = newValue }
    }
    
    static func delete_isAgreeLegalDisclaimer() {
        isAgreeLegalDisclaimerStorage.deleteValue()
    }
    
    static func delete_isUserSubscribed() {
        isUserSubscribedStorage.deleteValue()
    }
    
    static func delete_isUserInFreeTrial() {
        isUserInFreeTrialStorage.deleteValue()
    }
    
    static func delete_freeTrialStartDate() {
        freeTrialStartDateStorage.deleteValue()
    }
}
