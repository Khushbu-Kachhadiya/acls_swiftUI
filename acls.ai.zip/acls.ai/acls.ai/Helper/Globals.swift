//
//  Globals.swift
//  acls.ai
//
//  Created by Developer1 on 03/04/24.
//

import Foundation
import SwiftUI

enum Globals {
    static let homeCategoryList: [HomeModel] = [
        HomeModel(image: "app.icn.cardiac_arrest", description: "Cardiac Arrest"),
        HomeModel(image: "app.icn.tachycardia", description: "Tachycardia"),
        HomeModel(image: "app.icn.bradycardia", description: "Bradycardia"),
        HomeModel(image: "app.icn.postcardiac_arrestCare", description: "Post Cardiac Arrest Care"),
    ]
    
    enum CardiaArrest {
        static var start =  StepModel(
            title: "Start CPR",
            subTitle: "Give oxygen & attach\nmonitor defribllator",
            stepLogTitle: "CPR",
            isPreviousStepCompleted: true
        )
        
        static var rythm0 = StepModel(
            title: "Rhythm Shockable ?",
            buttonTypes: [.no,.yes],
            yesStage: ButtonModal(Nextstage: stage1), noStage: ButtonModal(Nextstage: stage4)
        )
        
        static var rythm1 = StepModel(
            title: "Rhythm Shockable ?",
            buttonTypes: [.no,.yes],
            yesStage: ButtonModal(Nextstage: stage2),
            noStage: ButtonModal(Nextstage: stage6)
        )
        
        static var rythm2 = StepModel(title: "Rhythm Shockable ?", buttonTypes: [.no,.yes],yesStage: ButtonModal(Nextstage: stage3),noStage: ButtonModal(Nextstage: stage6))
        static var rythm4 = StepModel(title: "Rhythm Shockable ?", buttonTypes: [.no,.yes],yesStage: ButtonModal(Nextstage: stage5),noStage: ButtonModal(Nextstage: stage6))
        static var rythm5 = StepModel(title: "Rhythm Shockable ?", buttonTypes: [.no,.yes],yesStage: ButtonModal(Nextstage: stage2),noStage: ButtonModal(Nextstage: stage6))
        
        static var vFpVT = StepModel(title: "VF/pVT",stepLogTitle: "VF/pVT")
        static var shock = StepModel(title: "Shock", stepLogTitle: "Shock",titleImage: "app.icn.lightning")
        static var cpr1 = StepModel(title: "CPR 2 Min",subTitle: "IV/IO access", stepLogTitle: "CPR", buttonTypes: [.start], timer: "02:00",isStartButtonHidden: false)
        
        static var cpr2_4 = StepModel(title: "CPR 2 Min",subTitle: "IV/IO access", stepLogTitle: "CPR", buttonTypes: [.start],description: """
                                        \u{2022} Epinephrine
                                           every 3-5 min
                                        \u{2022} Consider advanced airway, capnography
                                        """, timer: "02:00", isStartButtonHidden: false)
        
        static var cpr3 = StepModel(title: "CPR 2 Min", subTitle: """
                                    \u{2022} Amiodarone or
                                       Lidocaine
                                    \u{2022} Treat reversible causes
                                    """, stepLogTitle: "CPR",buttonTypes: [.start],timer: "02:00",isLastStep: true)
        
        static var cpr5 = StepModel(title: "CPR 2 Min",subTitle: "Treat revisable causes", stepLogTitle: "CPR", buttonTypes: [.start],timer: "02:00", isStartButtonHidden: false)
        static var asystolePEA = StepModel(title: "Asystole/PEA", stepLogTitle: "Asystole/PEA")
        static var epinephrineASAP = StepModel(title: "Epinephrine ASAP", stepLogTitle: "EPI", titleImage: "app.icn.epinephrine")
        static var finalStep = StepModel(subTitle: """
                                            \u{2022} If no signs of return of spontaneous
                                               circulation (ROSC), go to 10 or 11
                                            \u{2022} If ROSC, go to
                                            """, stepLogTitle: "Ended",
                                         buttonTypes: [.postCradiac], description: """
                                            \u{2022} Consider appropriateness of continued
                                               resuscitation
                                            """, isStartButtonHidden: false,isLastStep: true)
        
        static var stage0 = [start,rythm0,unknownStep]
        static var stage1 = [vFpVT,shock,cpr1,rythm1,unknownStep]
        static var stage2 = [shock,cpr2_4,rythm2,Globals.unknownStep]
        static var stage3 = [shock,cpr3]
        static var stage4 = [asystolePEA,epinephrineASAP,cpr2_4,rythm4,unknownStep]
        static var stage5 = [cpr5,rythm5,unknownStep]
        static var stage6 = [finalStep]
        
    }
    
    static var unknownStep = StepModel(
        description:"Waiting for a response to show next step",
        isLastStep: true
    )
}

enum ButtonType: String {
    case yes = "Yes"
    case no = "No"
    case start = "Start"
    case postCradiac = "Post-Cardiac Arrest Care"
    
    var title: String {
        self.rawValue
    }
    
    var color: Color {
        switch self {
        case .yes:
                .appLimeColor
        case .no:
                .appRedColor
        case .start:
                .appSkyColor
        case .postCradiac:
                .appSkyColor
        }
    }
}

//MARK: - Padding margins
enum PaddingType {
    case vary_small
    case small
    case normal
    case medium
    case large
    case very_large
    
    var value: CGFloat {
        switch self {
        case .small: return 8
        case .medium: return 24
        case .large: return 32
        case .vary_small: return 4
        case .normal: return 16
        case .very_large: return 64
        }
    }
}

enum FrameType{
    case very_small
    case small
    case large
    case very_large
    case normal
    case medium
    case textFieldHeight
    case tabBarHeight
    
    var value: CGFloat{
        switch self{
            
        case .very_small: return 10
        case .small: return 24
        case .large: return 300
        case .very_large: return 550
        case .normal: return 80
        case .medium: return 40
        case .textFieldHeight: return 56
        case .tabBarHeight: return 108
        }
    }
}

