//
//  ContentView.swift
//  acls.ai
//
//  Created by Sandeep Chandappillai on 3/21/24.
//

import SwiftUI

struct ContentView: View {
    @State var progress: Double = 1
    let timer = Timer.publish(every: 0.03, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack{
            Color.appBlackLightColor
                .ignoresSafeArea()
            VStack{
                CircularProgressView(progress: progress)
                    .frame(width: 280.asDeviceWidth, height: 280.asDeviceHeight, alignment: .center)
            }.padding(.horizontal)
        }
        .onReceive(timer) { _ in
            if progress < 0.25 {
                progress += 0.01
            }
        }
    }
}

#Preview {
    ContentView()
}



