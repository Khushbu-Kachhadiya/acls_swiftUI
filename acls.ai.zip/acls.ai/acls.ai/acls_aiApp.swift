//
//  acls_aiApp.swift
//  acls.ai
//
//  Created by Sandeep Chandappillai on 3/21/24.
//

import SwiftUI

@main
struct acls_aiApp: App {
    @StateObject
    private var entitlementManager: EntitlementManager
    
    @StateObject
    private var subscriptionsManager: SubscriptionsManager
    
    init() {
        let entitlementManager = EntitlementManager()
        let subscriptionsManager = SubscriptionsManager(entitlementManager: entitlementManager)
        
        self._entitlementManager = StateObject(wrappedValue: entitlementManager)
        self._subscriptionsManager = StateObject(wrappedValue: subscriptionsManager)
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                if KeychainStorageManager.isAgreeLegalDisclaimer {
                    if !KeychainStorageManager.isUserSubscribed && KeychainStorageManager.isUserInFreeTrial{
                        HomeView()
                    }else if !KeychainStorageManager.isUserSubscribed && !KeychainStorageManager.isUserInFreeTrial{
                        PaymentView()
                    }else{
                        HomeView()
                    }
                } else{
                    LegalDisclamerView()
                }
            }
            .environmentObject(entitlementManager)
            .environmentObject(subscriptionsManager)
            .task {
                await subscriptionsManager.updatePurchasedProducts()
            }
        }
    }
}
