//
//  acls_aiApp.swift
//  acls.ai
//
//  Created by Sandeep Chandappillai on 3/21/24.
//

import SwiftUI

@main
struct acls_aiApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                if KeychainStorageManager.isAgreeLegalDisclaimer {
                    if !KeychainStorageManager.isUserSubscribed && KeychainStorageManager.isUserInFreeTrial{
                        HomeView()
                    }else if !KeychainStorageManager.isUserSubscribed && !KeychainStorageManager.isUserInFreeTrial{
                        PaymentView()
                    }else{
                        HomeView()
                    }
                } else{
                    LegalDisclamerView()
                }
            }
        }
    }
}
